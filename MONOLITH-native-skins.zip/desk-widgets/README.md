# MONOLITH

Two desktop widgets for Windows, built with Electron:

- **Battery panel**: this laptop plus Bluetooth devices that report a level (headphones, mouse, keyboard); rings or bars, low-battery alerts
- **Clock & weather** widget and a **To-do** widget (off by default; turn it on in the tray menu)
- Themes: **Clay**, **Material**, **Apple** (iOS-style glass, SF Pro font if installed)
- **Music widget**: shows whatever Windows says is playing (Spotify, YouTube in Chrome/Edge, etc.) with album art, progress, and play / skip / seek. Clay or Material theme.
- **CPU & RAM widget**: rings, bars or big numbers, plus a history graph, per-core bars, disk usage and uptime.

## Run

1. Install Node.js LTS from https://nodejs.org
2. Double-click `start.bat` (first run installs Electron, about 100 MB)

`start.bat` closes itself after launching, so the widgets keep running with no command window.
After the first run you can also just double-click `start-hidden.vbs`.
To stop them: tray icon > Quit.

(Developers: `npm install` then `npm start` runs it attached to the terminal.)

## Use

- Tray icon (bottom-right, near the clock): toggle widgets, edit mode, settings, quit.
- Right-click a widget: edit mode, settings, hide.
- Edit mode: drag a widget, then click **Done**. Positions are remembered.
- Settings window: every option applies live.
- Settings file: `%APPDATA%\desk-widgets\config.json` (editable by hand, restart after editing).

## Make a standalone .exe

    npm run dist

The portable exe appears in `dist/`. Run it once and turn on "Start with Windows" in Settings.

## More features

- **One-click looks** in Settings (Clay pastel, Material night, Apple glass, Minimal).
- **Hotkey** `Ctrl+Alt+W` shows / hides every widget (change or clear it in Settings).
- **Snap to edges** after dragging, with an adjustable gap.
- **Multi-monitor**: pick which display the widgets live on.
- **Network speed** and **battery** lines on the CPU/RAM widget (off by default).
- **Weather**: type a city in the clock settings (uses open-meteo.com, no account needed).
- **Export / import settings** to a JSON file to back up or share your setup.
- Margins around widgets are click-through, so they never block your desktop icons.

## Desktop only

Settings > Window layer > **Desktop only** keeps widgets just above the wallpaper/icons and below every app (this is the default).
Edit mode temporarily lifts them above apps so you can find and drag them; click **Done** to drop them back.

## Notes

- The "bouncing bars" on the music widget are an animation, not a real audio analyser.
- Acrylic blur is experimental: Windows draws the corners, so the clay roundness is ignored.
- Without acrylic, widgets are see-through (no blur). Lower "Translucency" to see more of the wallpaper.

## MONOLITH native Skin Studio (experimental)

Open **Settings → Advanced → Rainmeter-style Skin Studio**. You can import a folder containing `.ini` skins (recommended, because it keeps images/resources) or a single `.ini` file. Imported skins are copied into MONOLITH's user-data `skins` folder; the original files are not changed. Select **Run skin** to open it as a MONOLITH desktop window.

This is a native renderer for a **limited Rainmeter-style INI subset**, not a drop-in replacement for Rainmeter. Initial support includes basic `String`, `Image`, `Bar`, and simple `Shape` meters, positioning, a few text styles, `#Variables#`, and simple `Measure=Time` / `Measure=String` values. Compatibility with `Calc`, plugins, Lua scripts, complex formulas, dynamic variables, Rainmeter bangs/actions, and many other meter/measure options is incomplete or intentionally unsupported. Skin files are treated as configuration; scripts and commands are not executed. Import the whole skin folder when it depends on images or other resources.
