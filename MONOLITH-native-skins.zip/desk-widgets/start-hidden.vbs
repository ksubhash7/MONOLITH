' Starts MONOLITH with no console window, so there is nothing to close by accident.
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh  = CreateObject("WScript.Shell")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = dir
exe = dir & "\node_modules\electron\dist\electron.exe"
If Not fso.FileExists(exe) Then
  MsgBox "Electron is not installed yet. Run start.bat once.", 48, "MONOLITH"
Else
  sh.Run Chr(34) & exe & Chr(34) & " " & Chr(34) & dir & Chr(34), 1, False
End If
