(() => {
  const FONTS = ['Segoe UI Variable', 'Segoe UI', 'Bahnschrift', 'Arial Rounded MT Bold', 'Trebuchet MS', 'Verdana', 'Candara', 'Calibri', 'Georgia', 'Consolas', 'Comic Sans MS'];
  const PRESETS = ['#8b7cff', '#ff7a9c', '#4ecdc4', '#ffb84d', '#0a84ff', '#30d158', '#ff375f', '#ff9f0a', '#bf5af2'];
  const THEMES = [['clay', 'Clay (soft & puffy)'], ['material', 'Material You'], ['apple', 'Apple glass'], ['nothing', 'Nothing UI (mono + red)'], ['fluent', 'Fluent / Windows 11'], ['nord', 'Nord (cool blue)'], ['amoled', 'AMOLED black']];
  const INTERVALS = [[500, '0.5 s'], [1000, '1 s'], [2000, '2 s'], [5000, '5 s']];
  const pct = v => Math.round(v * 100) + '%';
  const px = v => v + 'px';

  // t = control type, p = path in config.json, l = label, num = select returns a number
  const look = id => [
    { p: id + '.theme', t: 'select', l: 'Theme', o: THEMES },
    { p: id + '.scale', t: 'range', l: 'Size', min: 0.6, max: 2, step: 0.05, fmt: pct },
    { p: id + '.opacity', t: 'range', l: 'Translucency (lower = more see-through)', min: 0.15, max: 1, step: 0.01, fmt: pct },
    { p: id + '.radius', t: 'range', l: 'Corner roundness', min: 0, max: 56, step: 1, fmt: px },
  ];

  const SCHEMA = [
    { title: 'One-click looks', hint: 'Applies a theme, colours and translucency to all widgets. You can still tweak everything afterwards.',
      buttons: [['Clay pastel', 'preset:clay'], ['Material night', 'preset:material'], ['Apple glass', 'preset:apple'], ['Nothing UI', 'preset:nothing'], ['Fluent', 'preset:fluent'], ['Nord', 'preset:nord'], ['AMOLED', 'preset:amoled'], ['Minimal', 'preset:minimal']], items: [] },

    { title: 'Your profile', hint: 'Add a name to personalize your desktop. Leave it blank if you prefer.', items: [
      { p: 'general.displayName', t: 'text', w: 240, l: 'Your name (optional)' },
    ] },

    { title: 'General (all widgets)', items: [
      { p: 'general.editMode', t: 'toggle', l: 'Edit mode: drag widgets to reposition them' },
      { p: 'general.layer', t: 'select', l: 'Window layer', o: [['desktop', 'Desktop only (behind apps)'], ['top', 'Always on top of apps'], ['normal', 'Normal window']] },
      { p: 'general.snap', t: 'toggle', l: 'Snap to screen edges after dragging' },
      { p: 'general.snapMargin', t: 'range', l: 'Gap from the screen edge', min: 0, max: 60, step: 1, fmt: px },
      { p: 'general.monitor', t: 'select', num: true, l: 'Show widgets on (moves them there)', o: [[0, 'Primary display'], [1, 'Display 1'], [2, 'Display 2'], [3, 'Display 3']] },
      { p: 'general.hotkey', t: 'text', w: 170, l: 'Hotkey to show / hide all widgets (blank = off)' },
      { p: 'general.mode', t: 'select', l: 'Colour mode', o: [['auto', 'Follow Windows'], ['dark', 'Dark'], ['light', 'Light']] },
      { p: 'general.font', t: 'select', l: 'Font', o: FONTS },
      { p: 'general.startWithWindows', t: 'toggle', l: 'Start with Windows' },
      { p: 'general.acrylic', t: 'toggle', l: 'Acrylic blur behind widgets (experimental, Windows 11, square corners)' },
    ] },

    { title: 'Music widget', items: [
      { p: 'music.enabled', t: 'toggle', l: 'Show music widget' },
      { p: 'music.demo', t: 'toggle', l: 'Demo track (preview the look without playing music)' },
      ...look('music'),
      { p: 'music.layout', t: 'select', l: 'Layout', o: [['horizontal', 'Wide (art on the left)'], ['vertical', 'Tall (art on top)']] },
      { p: 'music.accent', t: 'color', l: 'Accent colour' },
      { p: 'music.accentFromArt', t: 'toggle', l: 'Take the accent from the album art' },
      { p: 'music.artShape', t: 'select', l: 'Album art shape', o: [['rounded', 'Rounded'], ['circle', 'Circle'], ['square', 'Square']] },
      { p: 'music.spinArt', t: 'toggle', l: 'Spin circular art while playing' },
      { p: 'music.showArt', t: 'toggle', l: 'Show album art' },
      { p: 'music.showVisualizer', t: 'toggle', l: 'Show bouncing bars (animation only)' },
      { p: 'music.showProgress', t: 'toggle', l: 'Show progress bar' },
      { p: 'music.showControls', t: 'toggle', l: 'Show play / skip buttons' },
      { p: 'music.showSource', t: 'toggle', l: 'Show which app is playing' },
      { p: 'music.pollMs', t: 'select', num: true, l: 'Check for track changes every', o: INTERVALS },
    ] },

    { title: 'CPU & RAM widget', items: [
      { p: 'system.enabled', t: 'toggle', l: 'Show system widget' },
      ...look('system'),
      { p: 'system.style', t: 'select', l: 'Metric style', o: [['rings', 'Rings'], ['bars', 'Bars'], ['numbers', 'Big numbers']] },
      { p: 'system.accent', t: 'color', l: 'CPU colour' },
      { p: 'system.accent2', t: 'color', l: 'RAM colour' },
      { p: 'system.accent3', t: 'color', l: 'Disk colour' },
      { p: 'system.showCpu', t: 'toggle', l: 'Show CPU' },
      { p: 'system.showRam', t: 'toggle', l: 'Show RAM' },
      { p: 'system.showDisk', t: 'toggle', l: 'Show disk usage' },
      { p: 'system.diskDrive', t: 'text', l: 'Drive to monitor (e.g. C: or D:)' },
      { p: 'system.showNet', t: 'toggle', l: 'Show network speed (download / upload)' },
      { p: 'system.showBattery', t: 'toggle', l: 'Show battery level (laptops)' },
      { p: 'system.showGraph', t: 'toggle', l: 'Show history graph' },
      { p: 'system.showCores', t: 'toggle', l: 'Show per-core bars' },
      { p: 'system.showCpuName', t: 'toggle', l: 'Show processor name' },
      { p: 'system.showUptime', t: 'toggle', l: 'Show uptime' },
      { p: 'system.intervalMs', t: 'select', num: true, l: 'Refresh every', o: INTERVALS },
    ] },

    { title: 'Battery widget', hint: 'Shows this laptop plus Bluetooth devices that report a battery level to Windows (headphones, mice, keyboards). Phones usually do not.', items: [
      { p: 'battery.enabled', t: 'toggle', l: 'Show battery widget' },
      { p: 'battery.demo', t: 'toggle', l: 'Demo devices (preview the look)' },
      ...look('battery'),
      { p: 'battery.style', t: 'select', l: 'Style', o: [['rings', 'Rings (like the iPhone widget)'], ['bars', 'Bars']] },
      { p: 'battery.accent', t: 'color', l: 'Accent colour' },
      { p: 'battery.showLaptop', t: 'toggle', l: 'Show this laptop' },
      { p: 'battery.showBluetooth', t: 'toggle', l: 'Show Bluetooth devices' },
      { p: 'battery.lowThreshold', t: 'range', l: 'Turn orange at or below', min: 5, max: 50, step: 1, fmt: v => v + '%' },
      { p: 'battery.lowAlert', t: 'toggle', l: 'Windows notification when a device gets low' },
      { p: 'battery.hide', t: 'text', w: 200, l: 'Hide devices (names, comma-separated)' },
      { p: 'battery.intervalSec', t: 'select', num: true, l: 'Check every', o: [[30, '30 s'], [60, '1 min'], [120, '2 min'], [300, '5 min']] },
    ] },

    { title: 'Clock & weather widget', items: [
      { p: 'clock.enabled', t: 'toggle', l: 'Show clock widget' },
      ...look('clock'),
      { p: 'clock.style', t: 'select', l: 'Style', o: [['digital', 'Digital'], ['analog', 'Analog']] },
      { p: 'clock.accent', t: 'color', l: 'Accent colour' },
      { p: 'clock.hour12', t: 'toggle', l: '12-hour clock' },
      { p: 'clock.showSeconds', t: 'toggle', l: 'Show seconds' },
      { p: 'clock.showDate', t: 'toggle', l: 'Show date' },
      { p: 'clock.dateFormat', t: 'select', l: 'Date format', o: [['long', 'Wednesday, October 21'], ['short', 'Wed, Oct 21'], ['numeric', 'Numbers only']] },
      { p: 'clock.showWeather', t: 'toggle', l: 'Show weather (needs internet)' },
      { p: 'clock.city', t: 'text', w: 170, l: 'City for weather (e.g. Hyderabad)' },
      { p: 'clock.units', t: 'select', l: 'Temperature', o: [['c', '°C'], ['f', '°F']] },
    ] },

    { title: 'To-do widget', hint: 'Turned off by default. Click a task to tick it, double-click its text to edit.', items: [
      { p: 'notes.enabled', t: 'toggle', l: 'Show to-do widget' },
      { p: 'notes.title', t: 'text', w: 170, l: 'Title' },
      ...look('notes'),
      { p: 'notes.accent', t: 'color', l: 'Accent colour' },
      { p: 'notes.showDone', t: 'toggle', l: 'Keep completed tasks visible' },
    ] },

    { title: 'Advanced', hint: 'Custom CSS is injected into every widget. Try: .card { border: 2px solid hotpink; }', items: [
      { p: 'general.customCss', t: 'textarea', l: 'Custom CSS' },
    ], buttons: [
      ['Export settings…', 'exportConfig'], ['Import settings…', 'importConfig'],
      ['Rainmeter-style Skin Studio', 'skinStudio'], ['Reset widget positions', 'resetPositions'], ['Open config folder', 'openFolder'],
      ['Reset everything', 'resetAll', 'danger'], ['Quit MONOLITH', 'quit', 'danger'],
    ] },
  ];

  const root = document.getElementById('root');
  const controls = {};            // path -> { it, input, out }
  let cfg = null;

  const get = (o, p) => p.split('.').reduce((a, k) => (a == null ? a : a[k]), o);
  const send = (p, v) => {
    const keys = p.split('.'), patch = {};
    let cur = patch;
    keys.forEach((k, i) => { cur[k] = i === keys.length - 1 ? v : {}; cur = cur[k]; });
    window.api.setConfig(patch);
  };
  const el = (tag, props = {}, kids = []) => {
    const e = Object.assign(document.createElement(tag), props);
    kids.forEach(k => e.append(k));
    return e;
  };

  function makeControl(it) {
    const row = el('label', { className: 'row' + (it.t === 'textarea' ? ' col' : '') });
    row.append(el('span', { className: 'lbl', textContent: it.l }));
    const box = el('span', { className: 'ctl' });
    let input, out = null;

    if (it.t === 'toggle') {
      input = el('input', { type: 'checkbox', className: 'switch' });
      input.onchange = () => send(it.p, input.checked);
    } else if (it.t === 'select') {
      input = el('select');
      it.o.forEach(o => { const [v, t] = Array.isArray(o) ? o : [o, o]; input.append(el('option', { value: v, textContent: t })); });
      input.onchange = () => send(it.p, it.num ? Number(input.value) : input.value);
    } else if (it.t === 'range') {
      input = el('input', { type: 'range', min: it.min, max: it.max, step: it.step });
      out = el('span', { className: 'val' });
      input.oninput = () => { const v = Number(input.value); out.textContent = it.fmt(v); send(it.p, v); };
    } else if (it.t === 'color') {
      input = el('input', { type: 'color' });
      input.oninput = () => send(it.p, input.value);
      const sw = el('span', { className: 'sw' });
      PRESETS.forEach(c => {
        const b = el('button', { type: 'button', title: c });
        b.style.background = c;
        b.onclick = e => { e.preventDefault(); input.value = c; send(it.p, c); };
        sw.append(b);
      });
      box.append(sw);
    } else if (it.t === 'text') {
      input = el('input', { type: 'text' });
      if (it.w) input.style.width = input.style.minWidth = it.w + 'px';
      input.onchange = () => send(it.p, input.value.trim());
    } else if (it.t === 'textarea') {
      input = el('textarea', { spellcheck: false });
      input.oninput = () => send(it.p, input.value);
    }
    box.append(input);
    if (out) box.append(out);
    row.append(box);
    controls[it.p] = { it, input, out };
    return row;
  }

  function build() {
    SCHEMA.forEach(sec => {
      const s = el('section');
      s.append(el('h2', { textContent: sec.title }));
      if (sec.hint) s.append(el('p', { className: 'hint', textContent: sec.hint }));
      sec.items.forEach(it => s.append(makeControl(it)));
      if (sec.buttons) {
        const a = el('div', { className: 'actions' });
        sec.buttons.forEach(([t, name, cls]) => a.append(el('button', { className: 'btn ' + (cls || ''), textContent: t, type: 'button', onclick: () => window.api.action(name) })));
        s.append(a);
      }
      root.append(s);
    });
  }

  function sync() {
    for (const [p, c] of Object.entries(controls)) {
      const v = get(cfg, p);
      if (document.activeElement === c.input || v === undefined) continue;
      if (c.it.t === 'toggle') c.input.checked = !!v;
      else if (c.it.t === 'range') { c.input.value = v; c.out.textContent = c.it.fmt(Number(v)); }
      else c.input.value = v;
    }
  }

  build();
  window.api.onConfig(c => { cfg = c; sync(); });
  window.api.ready('settings');
})();
