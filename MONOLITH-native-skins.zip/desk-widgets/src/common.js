/* Shared runtime for both widgets. Exposes window.W */
(() => {
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const hex2rgb = h => {
    h = (h || '#888888').replace('#', '');
    if (h.length === 3) h = [...h].map(c => c + c).join('');
    const n = parseInt(h, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  };
  const rgb2hex = c => '#' + c.map(v => clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0')).join('');
  const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
  const lum = c => {
    const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); };
    return .2126 * f(c[0]) + .7152 * f(c[1]) + .0722 * f(c[2]);
  };

  // 'auto' follows Windows, 'schedule' goes dark between darkFrom and darkTo
  function resolveMode(g) {
    if (g.mode === 'dark' || g.mode === 'light') return g.mode;
    if (g.mode === 'schedule') {
      const mins = t => { const [h, m] = String(t || '0:0').split(':').map(Number); return (h || 0) * 60 + (m || 0); };
      const n = new Date(), now = n.getHours() * 60 + n.getMinutes(), a = mins(g.darkFrom), b = mins(g.darkTo);
      const dark = a <= b ? (now >= a && now < b) : (now >= a || now < b);
      return dark ? 'dark' : 'light';
    }
    return matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  const W = { id: null, cfg: null, refresh: null, hex2rgb, rgb2hex, mix, clamp };

  // Turns the settings into CSS variables. `accentOverride` lets the music widget use the album colour.
  W.apply = function (accentOverride) {
    const cfg = W.cfg, g = cfg.general, w = cfg[W.id];
    const root = document.documentElement.style, body = document.body;
    const mode = resolveMode(g);
    const dark = mode === 'dark';
    const accent = accentOverride || w.accent;
    const ac = hex2rgb(accent);

    const base = w.theme === 'clay'
      ? mix(dark ? [46, 42, 68] : [244, 238, 255], ac, dark ? .14 : .12)
      : w.theme === 'apple'
        ? mix(dark ? [30, 30, 34] : [250, 250, 253], ac, dark ? .04 : .03)
        : w.theme === 'nothing' || w.theme === 'amoled'
          ? (dark ? (w.theme === 'amoled' ? [0, 0, 0] : [15, 15, 16]) : [248, 248, 248])
          : w.theme === 'nord'
            ? (dark ? [46, 52, 64] : [236, 239, 244])
            : w.theme === 'fluent'
              ? mix(dark ? [32, 32, 36] : [245, 245, 248], ac, dark ? .08 : .05)
              : mix(dark ? [32, 30, 40] : [251, 248, 255], ac, dark ? .12 : .09);
    const hi = mix(base, [255, 255, 255], dark ? .07 : .55);
    const lo = mix(base, [0, 0, 0], dark ? .8 : .5).map(Math.round).join(',');
    const set = (k, v) => root.setProperty(k, v);

    set('--accent', accent);
    set('--accent-rgb', ac.join(','));
    set('--accent-fg', lum(ac) > .55 ? '#17151f' : '#ffffff');
    set('--surface-rgb', base.map(Math.round).join(','));
    set('--surface-hi-rgb', hi.map(Math.round).join(','));
    set('--op', w.opacity);
    set('--radius', w.radius + 'px');
    set('--fg', dark ? '#f2eeff' : '#1e1b2e');
    set('--fg-dim', dark ? 'rgba(242,238,255,.62)' : 'rgba(30,27,46,.62)');
    set('--track', dark ? 'rgba(255,255,255,.14)' : 'rgba(30,27,46,.12)');
    set('--hi', dark ? 'rgba(255,255,255,.10)' : 'rgba(255,255,255,.85)');
    set('--hi-out', dark ? 'rgba(255,255,255,0)' : 'rgba(255,255,255,.55)');
    set('--lo', `rgba(${lo},${dark ? .55 : .38})`);
    set('--lo2', `rgba(${lo},${dark ? .32 : .2})`);
    set('--edge', dark ? 'rgba(255,255,255,.12)' : 'rgba(255,255,255,.75)');
    set('--edge-hi', dark ? 'rgba(255,255,255,.2)' : 'rgba(255,255,255,.9)');
    const sf = w.theme === 'apple' ? '"SF Pro Display","SF Pro Text",-apple-system,' : '';
    set('--font', `${sf}"${g.font}","Segoe UI Variable","Segoe UI",system-ui,sans-serif`);

    body.dataset.theme = w.theme;
    body.dataset.mode = mode;
    body.classList.toggle('editing', !!g.editMode);
    body.classList.toggle('acrylic', !!g.acrylic);

    let style = document.getElementById('custom-css');
    if (!style) { style = document.createElement('style'); style.id = 'custom-css'; document.head.appendChild(style); }
    style.textContent = g.customCss || '';

    // "Done" pill while in edit mode
    const stage = document.querySelector('.stage');
    let pill = stage.querySelector('.done-pill');
    if (g.editMode && !pill) {
      pill = document.createElement('button');
      pill.className = 'done-pill';
      pill.textContent = 'Done';
      pill.onclick = () => window.api.setConfig({ general: { editMode: false } });
      stage.appendChild(pill);
    } else if (!g.editMode && pill) pill.remove();
  };

  W.init = function (id, onConfig) {
    W.id = id;
    const stage = document.querySelector('.stage');
    let last = '';
    const report = () => {
      if (!W.cfg) return;
      const w = stage.offsetWidth, h = stage.offsetHeight, k = w + 'x' + h;
      if (k !== last) { last = k; window.api.resize(id, w, h); }
    };
    new ResizeObserver(report).observe(stage);

    window.api.onConfig(cfg => {
      W.cfg = cfg;
      onConfig(cfg);
      requestAnimationFrame(report);
    });
    matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (W.cfg && W.refresh) W.refresh(); });
    setInterval(() => { if (W.cfg && W.cfg.general.mode === 'schedule' && W.refresh) W.refresh(); }, 30000);
    window.addEventListener('contextmenu', e => { e.preventDefault(); window.api.menu(id); });

    // Invisible margins let clicks fall through to the desktop; only the card itself catches the mouse.
    let hit = false;
    const setHit = h => { if (h !== hit) { hit = h; window.api.hit(h); } };
    document.addEventListener('mousemove', e => setHit(!!e.target.closest('.card, .done-pill')));
    document.documentElement.addEventListener('mouseleave', () => setHit(false));

    // Material ripple
    document.addEventListener('pointerdown', e => {
      const b = e.target.closest('.ibtn, .play');
      if (!b || document.body.dataset.theme !== 'material') return;
      const r = b.getBoundingClientRect(), d = Math.max(r.width, r.height) * 2;
      const s = document.createElement('span');
      s.className = 'ripple';
      s.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
      b.appendChild(s);
      setTimeout(() => s.remove(), 600);
    });

    window.api.ready(id);
  };

  window.W = W;
})();
