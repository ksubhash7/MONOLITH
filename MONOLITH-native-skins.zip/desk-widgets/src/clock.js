(() => {
  const card = document.getElementById('card');
  let built = '';
  let wx = null, wxKey = '', wxAt = 0;

  // WMO weather codes -> [icon, text]
  const WMO = (code, day) => {
    if (code === 0) return day ? ['☀️', 'Clear'] : ['🌙', 'Clear'];
    if (code === 1) return day ? ['🌤️', 'Mostly clear'] : ['🌙', 'Mostly clear'];
    if (code === 2) return ['⛅', 'Partly cloudy'];
    if (code === 3) return ['☁️', 'Overcast'];
    if (code === 45 || code === 48) return ['🌫️', 'Fog'];
    if (code >= 51 && code <= 57) return ['🌦️', 'Drizzle'];
    if (code >= 61 && code <= 67) return ['🌧️', 'Rain'];
    if (code >= 71 && code <= 77) return ['❄️', 'Snow'];
    if (code >= 80 && code <= 82) return ['🌧️', 'Showers'];
    if (code === 85 || code === 86) return ['🌨️', 'Snow showers'];
    if (code >= 95) return ['⛈️', 'Thunderstorm'];
    return ['🌡️', 'Weather'];
  };

  function analogSvg() {
    let ticks = '';
    for (let i = 0; i < 12; i++) {
      const a = i * 30 * Math.PI / 180, big = i % 3 === 0, r1 = big ? 56 : 62, r2 = 68;
      ticks += `<line class="tick${big ? ' big' : ''}" x1="${80 + Math.sin(a) * r1}" y1="${80 - Math.cos(a) * r1}" x2="${80 + Math.sin(a) * r2}" y2="${80 - Math.cos(a) * r2}"/>`;
    }
    return `<svg class="face" viewBox="0 0 160 160"><circle class="rim" cx="80" cy="80" r="76"/>${ticks}
      <line id="hh" class="hand h" x1="80" y1="80" x2="80" y2="46"/>
      <line id="mh" class="hand m" x1="80" y1="80" x2="80" y2="28"/>
      <line id="sh" class="hand s" x1="80" y1="90" x2="80" y2="22"/>
      <circle class="pin" cx="80" cy="80" r="4"/></svg>`;
  }

  function build() {
    const c = W.cfg.clock;
    const key = [c.style, c.showDate, c.showWeather].join('|');
    if (key === built) return;
    built = key;
    let h = c.style === 'analog' ? analogSvg() : '<div class="c-time" id="time"></div>';
    if (c.showDate) h += '<div class="c-date" id="date"></div>';
    if (c.showWeather) h += '<div class="c-weather" id="wx" hidden></div>';
    card.innerHTML = h;
    paintWeather();
  }

  function tick() {
    if (!W.cfg) return;
    const c = W.cfg.clock, d = new Date();

    if (c.style === 'analog') {
      const sec = d.getSeconds(), min = d.getMinutes() + sec / 60, hr = (d.getHours() % 12) + min / 60;
      const set = (id, a) => { const el = document.getElementById(id); if (el) el.setAttribute('transform', `rotate(${a} 80 80)`); };
      set('hh', hr * 30); set('mh', min * 6); set('sh', sec * 6);
      const sh = document.getElementById('sh'); if (sh) sh.style.display = c.showSeconds ? '' : 'none';
    } else {
      const el = document.getElementById('time');
      if (el) {
        const parts = new Intl.DateTimeFormat(undefined, {
          hour: c.hour12 ? 'numeric' : '2-digit', minute: '2-digit',
          second: c.showSeconds ? '2-digit' : undefined, hour12: !!c.hour12,
        }).formatToParts(d);
        const time = parts.filter(p => p.type !== 'dayPeriod').map(p => p.value).join('').trim();
        const per = parts.find(p => p.type === 'dayPeriod');
        el.innerHTML = '';
        el.append(time);
        if (per) { const s = document.createElement('small'); s.textContent = per.value; el.append(s); }
      }
    }

    const dEl = document.getElementById('date');
    if (dEl) {
      const f = c.dateFormat;
      dEl.textContent = f === 'numeric' ? d.toLocaleDateString()
        : d.toLocaleDateString(undefined, f === 'short' ? { weekday: 'short', month: 'short', day: 'numeric' } : { weekday: 'long', month: 'long', day: 'numeric' });
    }
  }

  // ---- weather (Open-Meteo, no key needed) ----
  function paintWeather() {
    const el = document.getElementById('wx');
    if (!el) return;
    const c = W.cfg.clock;
    if (!c.city) { el.hidden = true; return; }
    el.hidden = false;
    if (!wx) { el.textContent = 'Weather unavailable'; return; }
    const [icon, text] = WMO(wx.code, wx.day);
    el.textContent = `${icon} ${wx.t}°${c.units === 'f' ? 'F' : 'C'} · ${text} · ${wx.name}`;
  }
  async function loadWeather() {
    const c = W.cfg && W.cfg.clock;
    if (!c || !c.showWeather || !c.city) return;
    const key = c.city + '|' + c.units;
    if (key === wxKey && Date.now() - wxAt < 15 * 60e3) return;     // fresh enough
    wxKey = key; wxAt = Date.now();
    try {
      const g = await (await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(c.city)}&count=1`)).json();
      const r = g.results && g.results[0];
      if (!r) throw new Error('city not found');
      const u = c.units === 'f' ? 'fahrenheit' : 'celsius';
      const w = await (await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${r.latitude}&longitude=${r.longitude}&current=temperature_2m,weather_code,is_day&temperature_unit=${u}`)).json();
      wx = { t: Math.round(w.current.temperature_2m), code: w.current.weather_code, day: w.current.is_day, name: r.name };
    } catch {
      wx = null;
      wxAt = Date.now() - 14 * 60e3;     // try again in about a minute
    }
    paintWeather();
  }

  const apply = () => W.apply(W.cfg.clock.accent);
  W.refresh = apply;
  W.init('clock', () => { apply(); build(); tick(); loadWeather(); });
  setInterval(tick, 500);
  setInterval(loadWeather, 60e3);
})();
