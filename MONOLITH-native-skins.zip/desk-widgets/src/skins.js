(() => {
  const list = document.getElementById('list');
  const esc = s => String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  async function render() {
    const skins = await window.api.listSkins(); list.replaceChildren();
    if (!skins.length) { list.innerHTML = '<div class="empty">No skins imported yet. Choose a folder containing .ini files, or import a single .ini file.</div>'; return; }
    for (const skin of skins) {
      const row = document.createElement('div'); row.className = 'skin';
      const info = document.createElement('div'); info.innerHTML = `<div class="name">${esc(skin.name)}</div><div class="path">${esc(skin.path)}</div>`;
      const btn = document.createElement('button'); btn.className = 'primary'; btn.textContent = 'Run skin'; btn.onclick = async () => { btn.disabled = true; try { await window.api.loadSkin(skin.id); } catch (e) { alert('Could not load skin: ' + e.message); } finally { btn.disabled = false; } };
      row.append(info, btn); list.append(row);
    }
  }
  document.getElementById('folder').onclick = async () => { try { await window.api.importSkinFolder(); await render(); } catch (e) { alert('Import failed: ' + e.message); } };
  document.getElementById('ini').onclick = async () => { try { await window.api.importSkinIni(); await render(); } catch (e) { alert('Import failed: ' + e.message); } };
  document.getElementById('refresh').onclick = render; render();
})();
