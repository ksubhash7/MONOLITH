(() => {
  const card = document.getElementById('card');
  let items = [];
  let built = false;
  let titleEl, countEl, listEl, addEl, clearEl;

  const uid = () => Math.random().toString(36).slice(2, 9);
  const save = () => window.api.setConfig({ notes: { items } });
  const CHECK = '<svg viewBox="0 0 24 24" width="14" height="14"><path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>';

  function skeleton() {
    card.innerHTML = `
      <div class="n-head"><div class="n-title"></div><div class="n-count"></div></div>
      <div class="n-list"></div>
      <input class="n-add" placeholder="Add a task…" maxlength="200" spellcheck="false">
      <button class="n-clear" type="button" hidden>Clear completed</button>`;
    titleEl = card.querySelector('.n-title'); countEl = card.querySelector('.n-count');
    listEl = card.querySelector('.n-list'); addEl = card.querySelector('.n-add'); clearEl = card.querySelector('.n-clear');

    addEl.addEventListener('keydown', e => {
      if (e.key !== 'Enter') return;
      const v = addEl.value.trim();
      if (!v) return;
      items.push({ id: uid(), t: v, d: false });
      addEl.value = '';
      save(); render();
    });
    clearEl.onclick = () => { items = items.filter(i => !i.d); save(); render(); };
    built = true;
  }

  function row(it) {
    const el = document.createElement('div');
    el.className = 'n-item' + (it.d ? ' done' : '');

    const box = document.createElement('button');
    box.className = 'box'; box.type = 'button'; box.title = it.d ? 'Mark as not done' : 'Mark as done';
    box.innerHTML = it.d ? CHECK : '';
    box.onclick = () => { it.d = !it.d; save(); render(); };

    const txt = document.createElement('span');
    txt.className = 'txt'; txt.textContent = it.t; txt.title = 'Double-click to edit';
    txt.ondblclick = () => {
      const inp = document.createElement('input');
      inp.className = 'n-edit'; inp.value = it.t; inp.maxLength = 200;
      txt.replaceWith(inp); inp.focus(); inp.select();
      const finish = () => {
        const v = inp.value.trim();
        if (v) it.t = v; else items = items.filter(x => x !== it);
        save(); render();
      };
      inp.onblur = finish;
      inp.onkeydown = e => { if (e.key === 'Enter') inp.blur(); if (e.key === 'Escape') { inp.value = it.t; inp.blur(); } };
    };

    const del = document.createElement('button');
    del.className = 'del'; del.type = 'button'; del.title = 'Delete'; del.textContent = '×';
    del.onclick = () => { items = items.filter(x => x !== it); save(); render(); };

    el.append(box, txt, del);
    return el;
  }

  function render() {
    if (!W.cfg) return;
    if (!built) skeleton();
    const c = W.cfg.notes;
    titleEl.textContent = c.title || 'To-do';
    const left = items.filter(i => !i.d).length;
    countEl.textContent = items.length ? `${left} left` : '';
    const shown = c.showDone ? items : items.filter(i => !i.d);
    listEl.replaceChildren(...shown.map(row));
    if (!shown.length) {
      const e = document.createElement('div');
      e.className = 'n-empty'; e.textContent = items.length ? 'All done 🎉' : 'Nothing here yet';
      listEl.append(e);
    }
    clearEl.hidden = !items.some(i => i.d);
  }

  const apply = () => W.apply(W.cfg.notes.accent);
  W.refresh = apply;
  W.init('notes', cfg => {
    const incoming = cfg.notes.items || [];
    const editing = !!document.querySelector('.n-edit');
    if (!editing && JSON.stringify(incoming) !== JSON.stringify(items)) items = incoming.map(x => ({ ...x }));
    apply();
    if (!editing) render();
  });
})();
