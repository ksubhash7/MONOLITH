(() => {
  const card = document.getElementById('card');
  let devices = [];
  let received = false;

  // Material icon paths (24x24)
  const ICON = {
    laptop: 'M20 18c1.1 0 1.99-.9 1.99-2L22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2H0v2h24v-2h-4zM4 6h16v10H4V6z',
    headphones: 'M12 1c-4.97 0-9 4.03-9 9v7c0 1.66 1.34 3 3 3h3v-8H5v-2c0-3.87 3.13-7 7-7s7 3.13 7 7v2h-4v8h3c1.66 0 3-1.34 3-3v-7c0-4.97-4.03-9-9-9z',
    mouse: 'M13 1.07V9h7c0-4.08-3.05-7.44-7-7.93zM4 15c0 4.42 3.58 8 8 8s8-3.58 8-8v-4H4v4zm7-13.93C7.05 1.56 4 4.92 4 9h7V1.07z',
    keyboard: 'M20 5H4c-1.1 0-1.99.9-1.99 2L2 17c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm-9 3h2v2h-2V8zm0 3h2v2h-2v-2zM8 8h2v2H8V8zm0 3h2v2H8v-2zm-1 2H5v-2h2v2zm0-3H5V8h2v2zm9 7H8v-2h8v2zm0-4h-2v-2h2v2zm0-3h-2V8h2v2zm3 3h-2v-2h2v2zm0-3h-2V8h2v2z',
    phone: 'M17 1.01 7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z',
    bluetooth: 'M17.71 7.71 12 2h-1v7.59L6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 11 14.41V22h1l5.71-5.71-4.3-4.29 4.3-4.29zM13 5.83l1.88 1.88L13 9.59V5.83zm1.88 10.46L13 18.17v-3.76l1.88 1.88z',
    bolt: 'M7 2v11h3v9l7-12h-4l4-8z',
  };
  const svg = (k, cls = '') => `<svg class="${cls}" viewBox="0 0 24 24"><path d="${ICON[k]}"/></svg>`;

  function kindOf(d) {
    if (d.kind === 'laptop') return 'laptop';
    const n = (d.name || '').toLowerCase();
    if (/head|buds|airpod|pods|earb|earphone|wh-|wf-|neckband|speaker/.test(n)) return 'headphones';
    if (/mouse|mx master|mx anywhere|trackpad|trackball/.test(n)) return 'mouse';
    if (/keyboard|keys|k380|k780/.test(n)) return 'keyboard';
    if (/phone|galaxy|iphone|pixel|redmi|oneplus|realme|oppo|vivo|xiaomi/.test(n)) return 'phone';
    return 'bluetooth';
  }

  function colorOf(d) {
    const c = W.cfg.battery, low = c.lowThreshold || 20;
    if (d.charging) return '#30d158';
    if (d.level <= 10) return '#ff453a';
    if (d.level <= low) return '#ff9f0a';
    return c.accent;
  }

  const esc = s => String(s).replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));

  function ring(d) {
    const col = colorOf(d), k = kindOf(d);
    return `<div class="b-ring" style="--c:${col}" title="${esc(d.name)}">
      <div class="rw">
        <svg viewBox="0 0 100 100"><circle class="tr" cx="50" cy="50" r="42"/><circle class="pg" cx="50" cy="50" r="42" pathLength="100" stroke-dasharray="100" stroke-dashoffset="${100 - d.level}"/></svg>
        <div class="ic">${svg(k)}</div>
      </div>
      <div class="pc">${d.level}%${d.charging ? svg('bolt', 'bolt') : ''}</div>
      <div class="nm">${esc(d.name)}</div>
    </div>`;
  }
  function row(d) {
    const col = colorOf(d), k = kindOf(d);
    return `<div class="b-row" style="--c:${col}">
      <div class="ic">${svg(k)}</div>
      <div class="body">
        <div class="top"><span class="nm">${esc(d.name)}</span><span class="pc">${d.level}%${d.charging ? svg('bolt', 'bolt') : ''}</span></div>
        <div class="track"><div class="pg" style="width:${d.level}%"></div></div>
      </div>
    </div>`;
  }

  const DEMO = [
    { kind: 'laptop', name: 'This laptop', level: 76, charging: true },
    { kind: 'bt', name: 'Sony WH-1000XM5', level: 58, charging: false },
    { kind: 'bt', name: 'MX Master 3S', level: 18, charging: false },
    { kind: 'bt', name: 'Keychron K2', level: 91, charging: false },
  ];

  function render() {
    if (!W.cfg) return;
    const c = W.cfg.battery;
    const list = (c.demo ? DEMO : devices).slice().sort((a, b) => (a.kind === 'laptop' ? -1 : b.kind === 'laptop' ? 1 : a.name.localeCompare(b.name)));
    let body;
    if (!list.length) {
      body = `<div class="b-empty">${c.demo || received
        ? 'No devices are reporting a battery level yet. Connect Bluetooth headphones, a mouse or a keyboard. Phones usually don’t report their battery to Windows.'
        : 'Looking for devices…'}</div>`;
    } else {
      body = c.style === 'bars'
        ? `<div class="b-rows">${list.map(row).join('')}</div>`
        : `<div class="b-rings">${list.map(ring).join('')}</div>`;
    }
    card.innerHTML = `<div class="b-head"><div class="b-title">Batteries</div><div class="b-sub">${list.length ? list.length + (list.length === 1 ? ' device' : ' devices') : ''}</div></div>${body}`;
  }

  window.api.onBattery(list => { devices = Array.isArray(list) ? list : []; received = true; render(); });

  const apply = () => W.apply(W.cfg.battery.accent);
  W.refresh = () => { apply(); render(); };
  W.init('battery', () => { apply(); render(); });
})();
