(() => {
  const surface = document.getElementById('surface'), title = document.getElementById('title');
  const skinId = new URLSearchParams(location.search).get('skin'); let data = null, timer = null;
  const num = (v, fallback=0) => { const n = Number(v); return Number.isFinite(n) ? n : fallback; };
  const pick = (o, k, fallback='') => o && o[k.toLowerCase()] != null ? o[k.toLowerCase()] : fallback;
  function variable(text, vars) { return String(text ?? '').replace(/#([A-Za-z0-9_]+)/g, (m, k) => vars[k] ?? vars[k.toLowerCase()] ?? m); }
  function getMeasure(name, measures, vars, now) {
    const m = measures[name]; if (!m) return '';
    const type = String(m.measure || '').toLowerCase();
    if (type === 'time') {
      const fmt = m.format || '%H:%M';
      const parts = {'%H':String(now.getHours()).padStart(2,'0'),'%I':String((now.getHours()%12)||12).padStart(2,'0'),'%M':String(now.getMinutes()).padStart(2,'0'),'%S':String(now.getSeconds()).padStart(2,'0'),'%p':now.getHours()<12?'AM':'PM','%d':String(now.getDate()).padStart(2,'0'),'%m':String(now.getMonth()+1).padStart(2,'0'),'%Y':String(now.getFullYear())};
      return fmt.replace(/%[HIMSpdYm]/g, x => parts[x] ?? x);
    }
    if (type === 'calc') return variable(m.formula || '', vars).replace(/[^0-9+*/().% -]/g, '').slice(0,80);
    if (type === 'string') return m.string || '';
    return '';
  }
  function render() {
    if (!data) return;
    title.textContent = data.name.toUpperCase().slice(0,40); surface.replaceChildren();
    const vars = {...data.vars}; Object.keys(vars).forEach(k => vars[k] = variable(vars[k], vars));
    const now = new Date(), values = {};
    for (const [name, m] of Object.entries(data.measures || {})) values[name] = getMeasure(name, data.measures, vars, now);
    const meters = data.meters || [];
    let maxX=0,maxY=0;
    for (const m of meters) { maxX=Math.max(maxX,num(m.x)+num(m.w,180)); maxY=Math.max(maxY,num(m.y)+num(m.h,28)); }
    surface.style.width = Math.max(100,maxX)+'px'; surface.style.height=Math.max(40,maxY)+'px';
    document.body.style.width=Math.max(130,maxX)+'px'; document.body.style.height=(Math.max(40,maxY)+22)+'px';
    document.getElementById('root').style.width='100%'; document.getElementById('root').style.height='100%';
    for (const m of meters) {
      const type=String(m.meter||'string').toLowerCase();
      if (!['string','image','bar','shape'].includes(type)) continue;
      const el=document.createElement('div'); el.className='meter'; el.style.left=num(m.x)+'px'; el.style.top=num(m.y)+'px';
      el.style.width=Math.max(1,num(m.w, type==='string'?240:100))+'px'; el.style.height=Math.max(1,num(m.h,type==='string'?30:20))+'px';
      el.style.color=m.fontcolor ? '#'+m.fontcolor.replace(/^#/,'') : '#f5f5f7';
      el.style.fontFamily=m.fontface || 'Segoe UI, Arial, sans-serif'; el.style.fontSize=Math.max(6,num(m.fontsize,14))+'px';
      el.style.fontWeight=String(m.bold).toLowerCase()==='1' || String(m.bold).toLowerCase()==='true'?'700':'400';
      el.style.textAlign=({left:'left',center:'center',right:'right'})[String(m.align||'left').toLowerCase()]||'left';
      if (type==='image') {
        const img=document.createElement('img'); const path=variable(m.imagerotate ? m.image : (m.image || ''),vars);
        if (path) img.src='file:///'+(data.root+'\\'+path.replaceAll('/','\\')).replaceAll('\\','/').replace(/^file:\/\//,'');
        img.alt=''; el.append(img);
      } else if (type==='bar') {
        el.classList.add('bar'); const fill=document.createElement('div'); fill.className='fill'; fill.style.width='50%'; fill.style.background=m.barcolor ? '#'+m.barcolor.replace(/^#/,'') : '#d8ff3e'; el.append(fill);
      } else if (type==='shape') {
        el.style.background=m.solidity ? `rgba(255,255,255,${Math.max(0,Math.min(1,num(m.solidity,100)/100))})` : '#d8ff3e'; el.style.borderRadius='4px';
      } else {
        let value=m.text || '';
        if (m.measurename) value=values[m.measurename] ?? value;
        value=variable(value,vars); value=value.replace(/\[([^\]]+)\]/g, (all,n) => values[n] ?? all);
        el.textContent=value;
      }
      surface.append(el);
    }
  }
  function acceptData(d) { data=d; render(); clearInterval(timer); timer=setInterval(render, Math.max(500,Math.min(10000,num(d.update,1000)))); }
  window.api.onSkinData(acceptData);
  window.api.getSkinData(skinId).then(acceptData).catch(e=>{surface.innerHTML='<div id="err">Could not load skin: '+String(e.message).replace(/[<>]/g,'')+'</div>';});
  document.getElementById('close').onclick=()=>window.api.closeSkin(); document.getElementById('refresh').onclick=()=>window.api.refreshSkin();
  document.getElementById('bar').ondblclick=()=>{};
})();
