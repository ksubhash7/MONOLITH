(() => {
  const card = document.getElementById('card');
  const N = 60;                                   // history length (samples)
  const hist = { cpu: [], ram: [] };
  let stats = null, built = '';
  let bat = { level: 1, charging: true, ok: false };
  const WARN = '#ff453a';

  const gb = b => (b / 1073741824).toFixed(1);
  const rate = b => b < 1024 ? Math.round(b) + ' B/s' : b < 1048576 ? Math.round(b / 1024) + ' KB/s' : (b / 1048576).toFixed(1) + ' MB/s';

  // Battery (laptops) via the browser Battery API
  let batt = null;
  function paintBattery() {
    const el = document.getElementById('batt');
    if (!el || !batt) return;
    el.textContent = `Battery ${Math.round(batt.level * 100)}%` + (batt.charging ? ' · charging' : '');
  }
  async function initBattery() {
    if (batt || !navigator.getBattery) return;
    try {
      batt = await navigator.getBattery();
      ['levelchange', 'chargingchange'].forEach(ev => batt.addEventListener(ev, paintBattery));
      paintBattery();
    } catch { /* no battery info */ }
  }
  const fmtUp = s => { const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60); return `Up ${d ? d + 'd ' : ''}${h}h ${m}m`; };

  const METRICS = { cpu: ['CPU', '--c1'], ram: ['RAM', '--c2'], disk: ['Disk', '--c3'], bat: ['Battery', '--c4'] };
  const enabled = c => [['cpu', c.showCpu], ['ram', c.showRam], ['disk', c.showDisk], ['bat', c.showBattery]].filter(x => x[1]).map(x => x[0]);

  function tpl(style, k) {
    const [label, col] = METRICS[k];
    if (style === 'rings') return `
      <div class="ring" data-k="${k}" style="--c:var(${col})">
        <svg viewBox="0 0 100 100"><circle class="tr" cx="50" cy="50" r="42"/><circle class="pg" cx="50" cy="50" r="42" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/></svg>
        <div class="val" data-v>0<small>%</small></div>
        <div class="lab">${label}</div><div class="sub" data-s></div>
      </div>`;
    if (style === 'bars') return `
      <div class="mbar" data-k="${k}" style="--c:var(${col})">
        <div class="row"><span>${label}</span><span data-v></span></div>
        <div class="track"><div class="pg"></div></div>
      </div>`;
    return `
      <div class="num" data-k="${k}" style="--c:var(${col})">
        <div class="big" data-v>0<small>%</small></div>
        <div class="lab">${label}</div><div class="sub" data-s></div>
      </div>`;
  }

  function build() {
    const c = W.cfg.system, list = enabled(c);
    const key = JSON.stringify([c.style, list, c.showGraph, c.showCores, c.showUptime, c.showCpuName, c.showNet, c.showBattery]);
    if (key === built) return;
    built = key;
    card.style.width = Math.max(330, list.length * 96 + 42) + 'px';
    let h = `<div class="sys-head"><div class="sys-title">System</div><div class="sys-sub" id="cpuname" ${c.showCpuName ? '' : 'hidden'}></div></div>`;
    h += list.length
      ? `<div class="metrics ${c.style}">${list.map(k => tpl(c.style, k)).join('')}</div>`
      : `<div class="sub">Turn on CPU, RAM, Disk or Battery in Settings.</div>`;
    if (c.showCores) h += '<div class="cores" id="cores"></div>';
    if (c.showGraph) h += '<canvas class="graph" id="graph"></canvas>';
    if (c.showNet) h += '<div class="extra" id="net">↓ –   ↑ –</div>';
    if (c.showBattery) h += '<div class="extra" id="batt"></div>';
    if (c.showUptime) h += '<div class="foot" id="uptime"></div>';
    card.innerHTML = h;
  }

  function pctOf(k) {
    if (k === 'cpu') return stats.cpu;
    if (k === 'ram') return stats.ram.pct;
    if (k === 'bat') return bat.level * 100;
    return stats.disk ? stats.disk.pct : 0;
  }
  function subOf(k) {
    if (k === 'cpu') return `${stats.cores.length} threads`;
    if (k === 'ram') return `${gb(stats.ram.used)} / ${gb(stats.ram.total)} GB`;
    if (k === 'bat') return bat.ok ? (bat.charging ? 'Charging / plugged in' : 'On battery') : 'No battery info';
    return stats.disk ? `${stats.disk.drive} ${gb(stats.disk.used)} / ${gb(stats.disk.total)} GB` : 'drive not found';
  }
  // high usage turns a metric red; for the battery it's *low* charge while unplugged
  function isWarn(k, p, c) {
    if (!c.warn) return false;
    if (k === 'bat') return bat.ok && !bat.charging && p <= 20;
    return p >= (c.warnAt || 85);
  }

  function update() {
    if (!stats || !W.cfg) return;
    const c = W.cfg.system;
    card.querySelectorAll('[data-k]').forEach(el => {
      const k = el.dataset.k, p = Math.max(0, Math.min(100, pctOf(k))), r = Math.round(p);
      el.style.setProperty('--c', isWarn(k, p, c) ? WARN : `var(${METRICS[k][1]})`);
      if (c.style === 'rings') {
        el.querySelector('.pg').style.strokeDashoffset = 100 - p;
        el.querySelector('[data-v]').innerHTML = r + '<small>%</small>';
        el.querySelector('[data-s]').textContent = subOf(k);
      } else if (c.style === 'bars') {
        el.querySelector('.pg').style.width = p + '%';
        el.querySelector('[data-v]').textContent = `${r}% · ${subOf(k)}`;
      } else {
        el.querySelector('[data-v]').innerHTML = r + '<small>%</small>';
        el.querySelector('[data-s]').textContent = subOf(k);
      }
    });
    const nt = document.getElementById('net');
    if (nt && stats.net) nt.textContent = `↓ ${rate(stats.net.down)}    ↑ ${rate(stats.net.up)}`;
    const nm = document.getElementById('cpuname'); if (nm) nm.textContent = stats.cpuName;
    const up = document.getElementById('uptime'); if (up) up.textContent = fmtUp(stats.uptime);
    const cores = document.getElementById('cores');
    if (cores) {
      while (cores.children.length < stats.cores.length) cores.appendChild(document.createElement('i'));
      while (cores.children.length > stats.cores.length) cores.lastChild.remove();
      stats.cores.forEach((v, i) => { cores.children[i].style.height = Math.max(8, v) + '%'; });
    }
    drawGraph();
  }

  function drawGraph() {
    const cv = document.getElementById('graph'); if (!cv) return;
    const c = W.cfg.system, dpr = window.devicePixelRatio || 1;
    const w = cv.offsetWidth, h = cv.offsetHeight;
    if (!w || !h) return;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    const g = cv.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, h);
    const series = [];
    if (c.showCpu) series.push([hist.cpu, c.accent]);
    if (c.showRam) series.push([hist.ram, c.accent2]);
    const step = w / (N - 1), y = v => h - 4 - (v / 100) * (h - 8);
    for (const [data, color] of series) {
      if (data.length < 2) continue;
      const pts = data.map((v, i) => [w - (data.length - 1 - i) * step, y(v)]);
      g.beginPath(); g.moveTo(pts[0][0], pts[0][1]);
      for (let i = 1; i < pts.length; i++) {
        const mx = (pts[i - 1][0] + pts[i][0]) / 2, my = (pts[i - 1][1] + pts[i][1]) / 2;
        g.quadraticCurveTo(pts[i - 1][0], pts[i - 1][1], mx, my);
      }
      g.lineTo(pts[pts.length - 1][0], pts[pts.length - 1][1]);
      g.strokeStyle = color; g.lineWidth = 2; g.lineJoin = 'round'; g.stroke();
      g.lineTo(pts[pts.length - 1][0], h); g.lineTo(pts[0][0], h); g.closePath();
      const gr = g.createLinearGradient(0, 0, 0, h);
      const rgb = W.hex2rgb(color).join(',');
      gr.addColorStop(0, `rgba(${rgb},.35)`); gr.addColorStop(1, `rgba(${rgb},0)`);
      g.fillStyle = gr; g.fill();
    }
  }

  function applyAll() {
    const c = W.cfg.system, r = document.documentElement.style;
    r.setProperty('--c1', c.accent); r.setProperty('--c2', c.accent2); r.setProperty('--c3', c.accent3); r.setProperty('--c4', c.accent4 || '#9be564');
    W.apply(c.accent);
    build();
    if (c.showBattery) initBattery();
    paintBattery();
    update();
  }

  window.api.onStats(s => {
    stats = s;
    hist.cpu.push(s.cpu); hist.ram.push(s.ram.pct);
    if (hist.cpu.length > N) { hist.cpu.shift(); hist.ram.shift(); }
    update();
  });

  // Battery (Chromium's Battery Status API; on a desktop PC it simply reports "plugged in, 100%")
  if (navigator.getBattery) {
    navigator.getBattery().then(b => {
      const read = () => { bat = { level: b.level, charging: b.charging, ok: true }; update(); };
      b.addEventListener('levelchange', read);
      b.addEventListener('chargingchange', read);
      read();
    }).catch(() => { /* no battery info */ });
  }

  W.refresh = applyAll;
  W.init('system', applyAll);
})();
