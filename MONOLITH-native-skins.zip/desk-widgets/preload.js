const { contextBridge, ipcRenderer } = require('electron');
const on = (channel, cb) => ipcRenderer.on(channel, (_e, ...args) => cb(...args));

contextBridge.exposeInMainWorld('api', {
  ready: id => ipcRenderer.send('ready', id),
  onConfig: cb => on('config', cb),
  onMedia: cb => on('media', cb),
  onStats: cb => on('stats', cb),
  onBattery: cb => on('battery', cb),
  onWeather: cb => on('weather', cb),
  setConfig: patch => ipcRenderer.invoke('config:set', patch),
  media: cmd => ipcRenderer.send('media:cmd', cmd),
  resize: (id, w, h) => ipcRenderer.send('widget:resize', id, w, h),
  menu: id => ipcRenderer.send('widget:menu', id),
  hit: h => ipcRenderer.send('widget:hit', !!h),
  action: name => ipcRenderer.send('app:action', name),
  listSkins: () => ipcRenderer.invoke('skins:list'),
  importSkinFolder: () => ipcRenderer.invoke('skins:import-folder'),
  importSkinIni: () => ipcRenderer.invoke('skins:import-ini'),
  loadSkin: id => ipcRenderer.invoke('skins:load', id),
  getSkinData: id => ipcRenderer.invoke('skins:data', id),
  onSkinData: cb => on('skin:data', cb),
  closeSkin: () => ipcRenderer.send('skins:close'),
  refreshSkin: () => ipcRenderer.send('skins:refresh'),
});
