'use strict';
const { app, BrowserWindow, Tray, Menu, ipcMain, nativeImage, screen, shell, dialog, globalShortcut, Notification } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn, execFile } = require('child_process');

const IDS = ['music', 'system', 'clock', 'notes', 'battery'];
const skinWins = new Map();
let skinManagerWin = null;
const TITLES = { music: 'Music widget', system: 'System widget', clock: 'Clock widget', notes: 'To-do widget', battery: 'Battery widget' };
const PAD = 34;   // invisible margin (CSS px) around every card, room for shadows

// ───────────────────────── defaults (every key here is editable in Settings) ─────────────────────────
const DEFAULTS = {
  general: {
    layer: 'desktop',        // 'desktop' = only on the desktop (behind apps), 'top' = above everything, 'normal' = regular window
    startWithWindows: false,
    editMode: false,         // true = drag widgets around
    mode: 'auto',            // 'auto' | 'dark' | 'light'
    font: 'Segoe UI Variable',
    acrylic: false,          // experimental real blur on Windows 11 (square corners)
    customCss: '',
    snap: true,              // snap to screen edges after dragging
    snapMargin: 12,
    monitor: 0,              // 0 = primary, 1.. = display number
    hotkey: 'Control+Alt+W', // show / hide all widgets (empty = off)
    displayName: '',       // optional name shown in the app's profile footer
  },
  music: {
    enabled: true, demo: false,
    theme: 'clay',           // 'clay' | 'material' | 'apple'
    layout: 'horizontal',    // 'horizontal' | 'vertical'
    scale: 1, opacity: 0.82, radius: 32,
    accent: '#8b7cff', accentFromArt: true,
    artShape: 'rounded',     // 'rounded' | 'circle' | 'square'
    spinArt: false,
    showArt: true, showVisualizer: true, showProgress: true, showControls: true, showSource: true,
    pollMs: 1000,
    x: null, y: null,
  },
  system: {
    enabled: true,
    theme: 'material',
    scale: 1, opacity: 0.82, radius: 28,
    accent: '#ff7a9c', accent2: '#4ecdc4', accent3: '#ffb84d',   // CPU, RAM, Disk colours
    style: 'rings',          // 'rings' | 'bars' | 'numbers'
    showCpu: true, showRam: true, showDisk: false,
    showGraph: true, showCores: false, showUptime: true, showCpuName: true,
    showNet: false, showBattery: false,
    intervalMs: 1000,
    diskDrive: 'C:',
    x: null, y: null,
  },
  clock: {
    enabled: true,
    theme: 'apple',
    scale: 1, opacity: 0.8, radius: 30,
    accent: '#0a84ff',
    style: 'digital',        // 'digital' | 'analog'
    hour12: false, showSeconds: false, showDate: true,
    dateFormat: 'long',      // 'long' | 'short' | 'numeric'
    showWeather: false, city: '', units: 'c',
    x: null, y: null,
  },
  notes: {
    enabled: false,
    theme: 'material',
    scale: 1, opacity: 0.85, radius: 24,
    accent: '#ffb84d',
    title: 'To-do',
    showDone: true,
    items: [],
    x: null, y: null,
  },
  battery: {
    enabled: true, demo: false,
    theme: 'apple',
    scale: 1, opacity: 0.78, radius: 28,
    accent: '#30d158',
    style: 'rings',          // 'rings' | 'bars'
    showLaptop: true, showBluetooth: true,
    lowThreshold: 20,        // turns orange at this %, red at 10%
    lowAlert: true,          // Windows notification when a device gets low
    hide: '',                // comma-separated device names to hide
    intervalSec: 60,
    x: null, y: null,
  },
};

// One-click looks (applied as a patch on top of your current settings)
const PRESET_PATCHES = {
  clay: {
    general: { mode: 'light' },
    music: { theme: 'clay', accent: '#ff7a9c', opacity: 0.85, radius: 34 },
    system: { theme: 'clay', accent: '#ff7a9c', accent2: '#4ecdc4', accent3: '#ffb84d', opacity: 0.85, radius: 34 },
    clock: { theme: 'clay', accent: '#ff7a9c', opacity: 0.85, radius: 34 },
    notes: { theme: 'clay', accent: '#ff7a9c', opacity: 0.88, radius: 30 },
    battery: { theme: 'clay', accent: '#4ecdc4', opacity: 0.85, radius: 34 },
  },
  material: {
    general: { mode: 'dark' },
    music: { theme: 'material', accent: '#8b7cff', opacity: 0.9, radius: 28 },
    system: { theme: 'material', accent: '#8b7cff', accent2: '#4ecdc4', accent3: '#ffb84d', opacity: 0.9, radius: 28 },
    clock: { theme: 'material', accent: '#8b7cff', opacity: 0.9, radius: 28 },
    notes: { theme: 'material', accent: '#8b7cff', opacity: 0.92, radius: 24 },
    battery: { theme: 'material', accent: '#4ecdc4', opacity: 0.9, radius: 28 },
  },
  apple: {
    general: { mode: 'auto' },
    music: { theme: 'apple', accent: '#0a84ff', opacity: 0.72, radius: 26 },
    system: { theme: 'apple', accent: '#ff375f', accent2: '#30d158', accent3: '#0a84ff', opacity: 0.72, radius: 26 },
    clock: { theme: 'apple', accent: '#0a84ff', opacity: 0.6, radius: 28 },
    notes: { theme: 'apple', accent: '#ff9f0a', opacity: 0.75, radius: 22 },
    battery: { theme: 'apple', accent: '#30d158', opacity: 0.72, radius: 26 },
  },
  nothing: {
    general: { mode: 'dark' },
    music: { theme: 'nothing', accent: '#e53935', opacity: 0.96, radius: 18 },
    system: { theme: 'nothing', accent: '#e53935', accent2: '#f4f4f4', accent3: '#777777', opacity: 0.96, radius: 18, style: 'bars' },
    clock: { theme: 'nothing', accent: '#e53935', opacity: 0.96, radius: 18 },
    notes: { theme: 'nothing', accent: '#e53935', opacity: 0.96, radius: 18 },
    battery: { theme: 'nothing', accent: '#e53935', opacity: 0.96, radius: 18, style: 'bars' },
  },
  fluent: {
    general: { mode: 'auto' },
    music: { theme: 'fluent', accent: '#60a5fa', opacity: 0.78, radius: 24 },
    system: { theme: 'fluent', accent: '#60a5fa', accent2: '#34d399', accent3: '#fbbf24', opacity: 0.78, radius: 24 },
    clock: { theme: 'fluent', accent: '#60a5fa', opacity: 0.78, radius: 24 },
    notes: { theme: 'fluent', accent: '#60a5fa', opacity: 0.8, radius: 24 },
    battery: { theme: 'fluent', accent: '#34d399', opacity: 0.78, radius: 24 },
  },
  nord: {
    general: { mode: 'dark' },
    music: { theme: 'nord', accent: '#88c0d0', opacity: 0.94, radius: 22 },
    system: { theme: 'nord', accent: '#88c0d0', accent2: '#a3be8c', accent3: '#ebcb8b', opacity: 0.94, radius: 22 },
    clock: { theme: 'nord', accent: '#88c0d0', opacity: 0.94, radius: 22 },
    notes: { theme: 'nord', accent: '#ebcb8b', opacity: 0.94, radius: 22 },
    battery: { theme: 'nord', accent: '#a3be8c', opacity: 0.94, radius: 22 },
  },
  amoled: {
    general: { mode: 'dark' },
    music: { theme: 'amoled', accent: '#ffffff', opacity: 1, radius: 16 },
    system: { theme: 'amoled', accent: '#ffffff', accent2: '#bdbdbd', accent3: '#777777', opacity: 1, radius: 16, style: 'bars' },
    clock: { theme: 'amoled', accent: '#ffffff', opacity: 1, radius: 16 },
    notes: { theme: 'amoled', accent: '#ffffff', opacity: 1, radius: 16 },
    battery: { theme: 'amoled', accent: '#ffffff', opacity: 1, radius: 16, style: 'bars' },
  },
  minimal: {
    music: { theme: 'apple', opacity: 0.45, radius: 18, showVisualizer: false, showSource: false },
    system: { theme: 'apple', opacity: 0.45, radius: 18, style: 'bars', showGraph: false, showCpuName: false, showUptime: false },
    clock: { theme: 'apple', opacity: 0.35, radius: 18, showDate: false },
    notes: { theme: 'apple', opacity: 0.5, radius: 16 },
    battery: { theme: 'apple', opacity: 0.45, radius: 18, style: 'bars' },
  },
};

// ───────────────────────── config storage ─────────────────────────
const CONFIG_PATH = path.join(app.getPath('userData'), 'config.json');
const FIRST_RUN = !fs.existsSync(CONFIG_PATH);

function readJson(p) { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; } }
function deepMerge(t, s) {
  for (const k of Object.keys(s || {})) {
    if (s[k] && typeof s[k] === 'object' && !Array.isArray(s[k])) {
      t[k] = deepMerge(t[k] && typeof t[k] === 'object' && !Array.isArray(t[k]) ? t[k] : {}, s[k]);
    } else t[k] = s[k];
  }
  return t;
}
let config = deepMerge(structuredClone(DEFAULTS), readJson(CONFIG_PATH) || {});

let persistTimer = null;
function writeNow() {
  try {
    fs.mkdirSync(path.dirname(CONFIG_PATH), { recursive: true });
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
  } catch (e) { console.error('config save failed', e); }
}
function schedulePersist() { clearTimeout(persistTimer); persistTimer = setTimeout(writeNow, 300); }

// ───────────────────────── state ─────────────────────────
const wins = {};            // widget windows
const sizes = {};           // last CSS size reported by each widget
let settingsWin = null;
let tray = null;
let quitting = false;       // only true when the user really quits (tray > Quit)
let hinted = false;
let widgetsHidden = false;  // toggled by the hotkey / tray

const webPreferences = {
  preload: path.join(__dirname, 'preload.js'),
  contextIsolation: true,
  nodeIntegration: false,
  backgroundThrottling: false,
};

function scriptPath(name) {
  return path.join(__dirname, 'scripts', name).replace(`app.asar${path.sep}`, `app.asar.unpacked${path.sep}`);
}

// ───────────────────────── layer: desktop / top / normal ─────────────────────────
// 'desktop' = pinned just above the wallpaper/icons. While editing, widgets jump on top so you can find and drag them.
// The to-do widget stays focusable so you can type in it.
function applyLayer(w) {
  if (!w || w.isDestroyed()) return;
  const l = config.general.layer, editing = !!config.general.editMode;
  w.setFocusable(w.deskId === 'notes' || l !== 'desktop' || editing);
  if (l === 'top' || (l === 'desktop' && editing)) w.setAlwaysOnTop(true, 'floating');
  else w.setAlwaysOnTop(false);
}
// Transparent margins should never block clicks on the desktop; the renderer tells us when the mouse is over a card.
function setClickThrough(w, through) {
  if (!w || w.isDestroyed()) return;
  if (through) w.setIgnoreMouseEvents(true, { forward: true });
  else w.setIgnoreMouseEvents(false);
}

let pin = null;
function hwndOf(win) {
  const b = win.getNativeWindowHandle();
  return b.length >= 8 ? Number(b.readBigUInt64LE(0)) : b.readUInt32LE(0);
}
function stopPin() { if (pin) { try { pin.kill(); } catch { /* ignore */ } pin = null; } }
function syncPin() {
  if (process.platform !== 'win32') return;
  const live = Object.values(wins).filter(w => w && !w.isDestroyed());
  if (config.general.layer !== 'desktop' || !live.length) { stopPin(); return; }
  if (!pin) {
    pin = spawn('powershell.exe',
      ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', scriptPath('pin.ps1')],
      { windowsHide: true });
    pin.stderr.on('data', d => console.error('[pin.ps1]', String(d)));
    pin.on('exit', () => { pin = null; });
  }
  const handles = config.general.editMode ? [] : live.map(hwndOf);   // don't fight the user while dragging
  if (pin && pin.stdin.writable) pin.stdin.write('pin ' + handles.join(',') + '\n');
}

// ───────────────────────── widget windows ─────────────────────────
function targetDisplay() {
  const ds = screen.getAllDisplays(), i = config.general.monitor || 0;
  return (i > 0 && ds[i - 1]) ? ds[i - 1] : screen.getPrimaryDisplay();
}
// Left column: system, clock, battery. Right column: music, to-do. Used until you drag a widget somewhere else.
const COLUMNS = { left: ['system', 'clock', 'battery'], right: ['music', 'notes'] };
const GUESS_H = { system: 340, clock: 170, battery: 230, music: 190, notes: 260 };   // until a widget reports its real size
function defaultPos(id) {
  const wa = targetDisplay().workArea;
  const s = (config[id] && config[id].scale) || 1;
  const sz = sizes[id] || { w: 420, h: 220 };
  const left = COLUMNS.left.includes(id);
  let y = wa.y + 16 - PAD;
  for (const other of COLUMNS[left ? 'left' : 'right']) {
    if (other === id) break;
    if (!config[other].enabled) continue;
    const o = sizes[other] || { h: GUESS_H[other] };
    y += Math.round((o.h - 2 * PAD + 12) * (config[other].scale || 1));
  }
  const x = left ? wa.x + 16 - PAD : Math.round(wa.x + wa.width - sz.w * s - 16 + PAD * s);
  return { x, y: Math.round(y) };
}
function onSomeDisplay(x, y) {
  return screen.getAllDisplays().some(d => {
    const b = d.bounds;
    return x >= b.x - 40 && x < b.x + b.width - 60 && y >= b.y - 10 && y < b.y + b.height - 60;
  });
}
// After a drag: pull the card's edge onto the screen edge if it is close
function snapWindow(win, id) {
  if (!config.general.snap || win.isDestroyed()) return;
  const b = win.getBounds(), s = config[id].scale || 1;
  const pad = config.general.acrylic ? 0 : Math.round(PAD * s);
  const wa = screen.getDisplayMatching(b).workArea;
  const m = config.general.snapMargin || 0, T = 28;
  let x = b.x, y = b.y;
  const left = b.x + pad, right = b.x + b.width - pad, top = b.y + pad, bottom = b.y + b.height - pad;
  if (Math.abs(left - (wa.x + m)) < T) x = wa.x + m - pad;
  else if (Math.abs(right - (wa.x + wa.width - m)) < T) x = wa.x + wa.width - m - (b.width - pad);
  if (Math.abs(top - (wa.y + m)) < T) y = wa.y + m - pad;
  else if (Math.abs(bottom - (wa.y + wa.height - m)) < T) y = wa.y + wa.height - m - (b.height - pad);
  if (x !== b.x || y !== b.y) win.setPosition(x, y);
}

function createWidget(id) {
  if (wins[id] && !wins[id].isDestroyed()) return;
  const c = config[id];
  const acrylic = !!config.general.acrylic;
  const pos = (c.x != null && c.y != null && onSomeDisplay(c.x, c.y)) ? { x: c.x, y: c.y } : defaultPos(id);

  const win = new BrowserWindow({
    ...pos, width: 420, height: 220, minWidth: 50, minHeight: 50, useContentSize: true,
    frame: false, transparent: !acrylic, backgroundColor: '#00000000',
    ...(acrylic ? { backgroundMaterial: 'acrylic' } : {}),
    resizable: false, maximizable: false, minimizable: false, fullscreenable: false,
    skipTaskbar: true, hasShadow: false, show: false,
    focusable: id === 'notes' || config.general.layer !== 'desktop' || config.general.editMode,
    webPreferences,
  });
  win.deskId = id;
  applyLayer(win);
  setClickThrough(win, !config.general.editMode);
  win.setMenuBarVisibility(false);
  win.on('show', syncPin);
  win.loadFile(path.join(__dirname, 'src', id + '.html'));
  win.webContents.on('dom-ready', () => win.webContents.setZoomFactor(config[id].scale || 1));

  let t;
  win.on('move', () => {
    clearTimeout(t);
    t = setTimeout(() => {
      if (win.isDestroyed()) return;
      const [x, y] = win.getPosition();
      config[id].x = x; config[id].y = y;
      schedulePersist();
    }, 300);
  });
  win.on('moved', () => snapWindow(win, id));
  win.on('close', e => { if (!quitting) e.preventDefault(); });   // widgets only go away via Settings / tray
  win.on('closed', () => { delete wins[id]; delete sizes[id]; });
  wins[id] = win;
}
function destroyWidget(id) {
  const w = wins[id];
  if (w && !w.isDestroyed()) w.destroy();
  delete wins[id];
}
function applySize(id) {
  const win = wins[id], sz = sizes[id];
  if (!win || win.isDestroyed() || !sz) return;
  const s = config[id].scale || 1;
  win.setContentSize(Math.ceil(sz.w * s), Math.ceil(sz.h * s));
  if (!win.isVisible() && !widgetsHidden) win.showInactive();
}
function syncWidgets() {
  for (const id of IDS) config[id].enabled ? createWidget(id) : destroyWidget(id);
  syncMedia();
  syncStats();
  syncBattery();
  syncPin();
  buildTray();
}
function resetPositions() {
  for (const id of IDS) {
    config[id].x = null; config[id].y = null;
    const w = wins[id];
    if (w && !w.isDestroyed()) { const p = defaultPos(id); w.setPosition(p.x, p.y); }
  }
  schedulePersist();
}
function setWidgetsHidden(h) {
  widgetsHidden = h;
  for (const w of Object.values(wins)) {
    if (w.isDestroyed()) continue;
    if (h) w.hide(); else w.showInactive();
  }
  buildTray();
}
function registerHotkey() {
  globalShortcut.unregisterAll();
  const k = (config.general.hotkey || '').trim();
  if (!k) return;
  try {
    if (!globalShortcut.register(k, () => setWidgetsHidden(!widgetsHidden))) console.error('Hotkey already in use:', k);
  } catch (e) { console.error('Invalid hotkey', k, e.message); }
}

// ───────────────────────── MONOLITH native skin runtime (Rainmeter-style INI subset) ─────────────────────────
const SKINS_DIR = path.join(app.getPath('userData'), 'skins');
function ensureSkinsDir() { fs.mkdirSync(SKINS_DIR, { recursive: true }); }
function walkIni(dir, root = dir, out = []) {
  let entries = []; try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const ent of entries) {
    const full = path.join(dir, ent.name);
    if (ent.isDirectory() && !ent.name.startsWith('.')) walkIni(full, root, out);
    else if (ent.isFile() && ent.name.toLowerCase().endsWith('.ini')) out.push({ path: full, rel: path.relative(root, full) });
  }
  return out;
}
function listNativeSkins() {
  ensureSkinsDir();
  return walkIni(SKINS_DIR).map(x => ({ id: x.rel, name: path.basename(x.rel, '.ini'), path: x.rel }));
}
function parseIni(file) {
  const text = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '');
  const sections = []; let current = null;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim(); if (!line || line.startsWith(';') || line.startsWith('#')) continue;
    const m = line.match(/^\[([^\]]+)\]$/);
    if (m) { current = { name: m[1].trim(), options: {} }; sections.push(current); continue; }
    const eq = line.indexOf('=');
    if (current && eq > 0) { const key = line.slice(0, eq).trim(); if (key) current.options[key.toLowerCase()] = line.slice(eq + 1).trim(); }
  }
  const vars = {}; const meters = []; const measures = {};
  for (const sec of sections) {
    if (sec.name.toLowerCase() === 'variables') Object.assign(vars, sec.options);
    if (sec.options.measure) measures[sec.name] = sec;
    if (sec.options.meter) meters.push(sec);
  }
  const rainmeter = (sections.find(x => x.name.toLowerCase() === 'rainmeter') || {}).options || {};
  return { name: path.basename(file, '.ini'), file, root: path.dirname(file), update: Math.max(250, Math.min(10000, Number(rainmeter.update) || 1000)), vars, meters, measures };
}
function skinPayload(id) {
  const full = path.resolve(SKINS_DIR, id);
  if (!full.startsWith(path.resolve(SKINS_DIR) + path.sep) || !fs.existsSync(full) || !full.toLowerCase().endsWith('.ini')) throw new Error('Skin file not found');
  const skin = parseIni(full);
  return { name: skin.name, id, update: skin.update, vars: skin.vars, meters: skin.meters.map(m => ({ name: m.name, ...m.options })), measures: Object.fromEntries(Object.entries(skin.measures).map(([k,v]) => [k, v.options])), root: skin.root };
}
function openSkinManager() {
  if (skinManagerWin && !skinManagerWin.isDestroyed()) { skinManagerWin.show(); skinManagerWin.focus(); return; }
  skinManagerWin = new BrowserWindow({ width: 760, height: 640, minWidth: 560, minHeight: 440, title: 'MONOLITH — Skin Studio', backgroundColor: '#111116', autoHideMenuBar: true, webPreferences });
  skinManagerWin.removeMenu(); skinManagerWin.loadFile(path.join(__dirname, 'src', 'skins.html'));
  skinManagerWin.on('closed', () => { skinManagerWin = null; });
}
function openNativeSkin(id) {
  const key = String(id);
  for (const [k, win] of skinWins) if (k === key && !win.isDestroyed()) { win.showInactive(); return; }
  const data = skinPayload(key);
  const skinWidth = Math.max(180, Math.min(1200, ...data.meters.map(m => Number(m.x || 0) + Number(m.w || 180)), 420));
  const skinHeight = Math.max(100, Math.min(900, ...data.meters.map(m => Number(m.y || 0) + Number(m.h || 28)), 280)) + 22;
  const win = new BrowserWindow({ width: skinWidth, height: skinHeight, minWidth: 100, minHeight: 60, frame: false, transparent: true, backgroundColor: '#00000000', resizable: true, skipTaskbar: true, show: false, webPreferences });
  win.skinId = key; win.setMenuBarVisibility(false); skinWins.set(key, win);
  win.loadFile(path.join(__dirname, 'src', 'skin-host.html'), { query: { skin: key } });
  win.webContents.on('did-finish-load', () => { win.webContents.send('skin:data', data); });
  win.once('ready-to-show', () => win.showInactive());
  win.on('closed', () => skinWins.delete(key));
}
function importSkinFolder(source) {
  ensureSkinsDir();
  const base = path.basename(source).replace(/[<>:"/\\|?*]/g, '_') || 'ImportedSkin';
  let dest = path.join(SKINS_DIR, base), n = 2;
  while (fs.existsSync(dest)) dest = path.join(SKINS_DIR, `${base} ${n++}`);
  fs.cpSync(source, dest, { recursive: true, filter: src => !src.split(path.sep).some(part => part === 'node_modules' || part === '.git' || part === '__MACOSX') });
  return listNativeSkins();
}

// ───────────────────────── settings window ─────────────────────────
function openSettings() {
  if (settingsWin && !settingsWin.isDestroyed()) { settingsWin.show(); settingsWin.focus(); return; }
  settingsWin = new BrowserWindow({
    width: 880, height: 760, minWidth: 660, minHeight: 480,
    title: 'MONOLITH — Settings', backgroundColor: '#14121c', autoHideMenuBar: true,
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences,
  });
  settingsWin.removeMenu();
  settingsWin.loadFile(path.join(__dirname, 'src', 'settings.html'));
  settingsWin.on('close', e => {
    if (quitting) return;
    e.preventDefault();
    settingsWin.hide();          // keep running in the system tray
    hintTray();
  });
  settingsWin.on('closed', () => { settingsWin = null; });
}

// ───────────────────────── tray ─────────────────────────
function hintTray() {
  if (hinted || !tray || process.platform !== 'win32') return;
  hinted = true;
  try {
    tray.displayBalloon({
      iconType: 'info',
      title: 'MONOLITH is still running',
      content: 'It lives in the system tray (the ^ arrow near the clock). Right-click the icon for options or to quit.',
    });
  } catch { /* ignore */ }
}
function buildTray() {
  if (!tray) {
    const img = nativeImage.createFromPath(path.join(__dirname, 'assets', 'icon.png')).resize({ width: 16, height: 16 });
    tray = new Tray(img);
    tray.setToolTip('MONOLITH');
    tray.on('click', openSettings);
    tray.on('double-click', openSettings);
  }
  const hk = (config.general.hotkey || '').trim();
  tray.setContextMenu(Menu.buildFromTemplate([
    ...IDS.map(id => ({ label: TITLES[id], type: 'checkbox', checked: config[id].enabled, click: m => applyPatch({ [id]: { enabled: m.checked } }) })),
    { type: 'separator' },
    { label: hk ? `Hide all widgets (${hk})` : 'Hide all widgets', type: 'checkbox', checked: widgetsHidden, click: m => setWidgetsHidden(m.checked) },
    { label: 'Edit mode (drag widgets)', type: 'checkbox', checked: config.general.editMode, click: m => applyPatch({ general: { editMode: m.checked } }) },
    { label: 'Settings…', click: openSettings },
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() },
  ]));
}

// ───────────────────────── config updates ─────────────────────────
function setAutoStart(on) {
  try {
    app.setLoginItemSettings(app.isPackaged
      ? { openAtLogin: on }
      : { openAtLogin: on, path: process.execPath, args: [app.getAppPath()] });
  } catch (e) { console.error(e); }
}
function allWindows() { return [...Object.values(wins), settingsWin].filter(w => w && !w.isDestroyed()); }
function broadcastConfig() { for (const w of allWindows()) w.webContents.send('config', config); }

function applyPatch(patch) {
  deepMerge(config, patch);
  schedulePersist();
  const g = patch.general || {};

  if ('startWithWindows' in g) setAutoStart(!!g.startWithWindows);
  if ('acrylic' in g) for (const id of IDS) destroyWidget(id);   // window must be recreated
  if ('hotkey' in g) { registerHotkey(); buildTray(); }
  if ('monitor' in g) resetPositions();

  for (const id of IDS) {
    if (patch[id] && 'scale' in patch[id] && wins[id]) {
      wins[id].webContents.setZoomFactor(config[id].scale);
      applySize(id);
    }
  }

  const enabledChanged = IDS.some(id => patch[id] && 'enabled' in patch[id]);
  if ('acrylic' in g || enabledChanged) syncWidgets();
  else {
    if (patch.music && ('demo' in patch.music || 'pollMs' in patch.music)) syncMedia();
    if (patch.system && ('intervalMs' in patch.system || 'showNet' in patch.system)) syncStats();
    if (patch.battery && ('demo' in patch.battery || 'intervalSec' in patch.battery)) syncBattery();
  }
  if (patch.battery) sendBattery();
  if ('layer' in g || 'editMode' in g) {
    for (const w of Object.values(wins)) { applyLayer(w); setClickThrough(w, !config.general.editMode); }
    syncPin();
  }
  if ('editMode' in g) buildTray();
  broadcastConfig();
}
function replaceConfig(next) {
  config = deepMerge(structuredClone(DEFAULTS), next || {});
  config.general.editMode = false;
  setAutoStart(!!config.general.startWithWindows);
  schedulePersist();
  for (const id of IDS) destroyWidget(id);
  registerHotkey();
  syncWidgets();
  broadcastConfig();
}

// ───────────────────────── export / import ─────────────────────────
async function exportConfig() {
  const opts = { title: 'Export settings', defaultPath: path.join(app.getPath('documents'), 'monolith-settings.json'), filters: [{ name: 'JSON', extensions: ['json'] }] };
  const parent = settingsWin && !settingsWin.isDestroyed() ? settingsWin : null;
  const r = parent ? await dialog.showSaveDialog(parent, opts) : await dialog.showSaveDialog(opts);
  if (r.canceled || !r.filePath) return;
  try { fs.writeFileSync(r.filePath, JSON.stringify(config, null, 2)); }
  catch (e) { dialog.showErrorBox('Export failed', e.message); }
}
async function importConfig() {
  const opts = { title: 'Import settings', properties: ['openFile'], filters: [{ name: 'JSON', extensions: ['json'] }] };
  const parent = settingsWin && !settingsWin.isDestroyed() ? settingsWin : null;
  const r = parent ? await dialog.showOpenDialog(parent, opts) : await dialog.showOpenDialog(opts);
  if (r.canceled || !r.filePaths[0]) return;
  const data = readJson(r.filePaths[0]);
  if (!data || typeof data !== 'object' || Array.isArray(data)) { dialog.showErrorBox('Import failed', 'That file is not a MONOLITH settings file.'); return; }
  replaceConfig(data);
}

// ───────────────────────── system stats ─────────────────────────
let prevCpu = os.cpus();
let statsTimer = null;
let lastStats = null;
let netPrev = null;
let netRate = { down: 0, up: 0 };

// Network speed from `netstat -e` (total bytes in/out), converted to bytes per second
function pollNet() {
  if (process.platform !== 'win32') return;
  execFile('netstat', ['-e'], { windowsHide: true, timeout: 4000 }, (err, out) => {
    if (err) return;
    const m = out.split(/\r?\n/).map(l => l.match(/^\s*\S+\s+(\d+)\s+(\d+)\s*$/)).find(Boolean);
    if (!m) return;
    const rx = Number(m[1]), tx = Number(m[2]), now = Date.now();
    if (netPrev) {
      const dt = (now - netPrev.t) / 1000;
      if (dt > 0) netRate = { down: Math.max(0, (rx - netPrev.rx) / dt), up: Math.max(0, (tx - netPrev.tx) / dt) };
    }
    netPrev = { rx, tx, t: now };
  });
}

function sampleStats() {
  const cur = os.cpus();
  let idleAll = 0, totalAll = 0;
  const cores = [];
  cur.forEach((c, i) => {
    const p = prevCpu[i] || c;
    let total = 0;
    for (const k in c.times) total += c.times[k] - p.times[k];
    const idle = c.times.idle - p.times.idle;
    idleAll += idle; totalAll += total;
    cores.push(total > 0 ? Math.round((1 - idle / total) * 100) : 0);
  });
  prevCpu = cur;

  const totalMem = os.totalmem(), freeMem = os.freemem();
  let disk = null;
  try {
    const drive = (config.system.diskDrive || 'C:').replace(/[\\/]+$/, '') + '\\';
    const st = fs.statfsSync(drive);
    const total = st.blocks * st.bsize, free = st.bavail * st.bsize;
    disk = { total, used: total - free, pct: ((total - free) / total) * 100, drive: drive.slice(0, 2) };
  } catch { /* drive missing */ }

  return {
    cpu: totalAll > 0 ? (1 - idleAll / totalAll) * 100 : 0,
    cores,
    cpuName: (cur[0] && cur[0].model ? cur[0].model : 'CPU').replace(/\s+/g, ' ').trim(),
    ram: { total: totalMem, used: totalMem - freeMem, pct: ((totalMem - freeMem) / totalMem) * 100 },
    disk,
    net: netRate,
    uptime: os.uptime(),
  };
}
function stopStats() { clearInterval(statsTimer); statsTimer = null; }
function syncStats() {
  stopStats();
  if (!wins.system) return;
  const tick = () => {
    if (config.system.showNet) pollNet();
    lastStats = sampleStats();
    if (wins.system && !wins.system.isDestroyed()) wins.system.webContents.send('stats', lastStats);
  };
  tick();
  statsTimer = setInterval(tick, Math.max(250, config.system.intervalMs || 1000));
}

// ───────────────────────── batteries (laptop + Bluetooth devices) ─────────────────────────
let batteryTimer = null;
let lastBattery = null;
const lowNotified = {};

function visibleBatteries(list) {
  const c = config.battery;
  const hide = String(c.hide || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean);
  return (list || []).filter(d =>
    (d.kind === 'laptop' ? c.showLaptop : c.showBluetooth) &&
    !hide.some(h => String(d.name).toLowerCase().includes(h)));
}
function sendBattery() {
  if (wins.battery && !wins.battery.isDestroyed()) wins.battery.webContents.send('battery', visibleBatteries(lastBattery));
}
function batteryAlerts(list) {
  if (!config.battery.lowAlert || !Notification.isSupported()) return;
  const th = config.battery.lowThreshold || 20;
  for (const d of list) {
    if (d.level <= th && !d.charging) {
      if (!lowNotified[d.name]) {
        lowNotified[d.name] = true;
        new Notification({ title: `${d.name} battery is low`, body: `${d.level}% remaining` }).show();
      }
    } else if (d.charging || d.level > th + 5) lowNotified[d.name] = false;
  }
}
function pollBattery() {
  if (!wins.battery) return;
  if (process.platform !== 'win32') { lastBattery = []; sendBattery(); return; }
  execFile('powershell.exe',
    ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', scriptPath('battery.ps1')],
    { windowsHide: true, timeout: 25000, maxBuffer: 1 << 20 },
    (err, stdout) => {
      let list;
      try { list = JSON.parse(String(stdout || '').trim() || '[]'); } catch { return; }
      if (!Array.isArray(list)) list = [list];
      lastBattery = list;
      sendBattery();
      batteryAlerts(visibleBatteries(list));
    });
}
function stopBattery() { clearInterval(batteryTimer); batteryTimer = null; }
function syncBattery() {
  stopBattery();
  if (!wins.battery || config.battery.demo) return;
  pollBattery();
  batteryTimer = setInterval(pollBattery, Math.max(15, config.battery.intervalSec || 60) * 1000);
}

// ───────────────────────── media (Windows "now playing") ─────────────────────────
let ps = null;
let wantMedia = false;
let mediaFails = 0;
let lastMedia = { active: false };
let lastKey = '';

function emitMedia(m) {
  if (m.active) {
    const same = m.key === lastKey;
    lastKey = m.key;
    lastMedia = { ...m, art: ('art' in m) ? m.art : (same ? lastMedia.art : null) };
  } else { lastKey = ''; lastMedia = m; }
  if (wins.music && !wins.music.isDestroyed()) wins.music.webContents.send('media', m);
}
function startMedia() {
  const t0 = Date.now();
  ps = spawn('powershell.exe',
    ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', scriptPath('media.ps1'), String(config.music.pollMs || 1000)],
    { windowsHide: true });
  let buf = '';
  ps.stdout.setEncoding('utf8');
  ps.stdout.on('data', d => {
    mediaFails = 0;
    buf += d;
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (line) { try { emitMedia(JSON.parse(line)); } catch { /* partial line */ } }
    }
  });
  ps.stderr.on('data', d => console.error('[media.ps1]', String(d)));
  ps.on('error', () => { ps = null; wantMedia = false; emitMedia({ active: false, error: true }); });
  ps.on('exit', () => {
    ps = null;
    if (!wantMedia) return;
    mediaFails = (Date.now() - t0 < 4000) ? mediaFails + 1 : 0;
    if (mediaFails >= 3) { wantMedia = false; emitMedia({ active: false, error: true }); return; }   // give up, tell the widget
    setTimeout(() => { if (wantMedia && !ps) startMedia(); }, 2000);
  });
}
function stopMedia() {
  wantMedia = false;
  if (ps) { try { ps.kill(); } catch { /* ignore */ } ps = null; }
}
function syncMedia() {
  stopMedia();
  mediaFails = 0;
  if (!wins.music || config.music.demo) return;
  if (process.platform !== 'win32') { emitMedia({ active: false, unsupported: true }); return; }
  wantMedia = true;
  startMedia();
}

// ───────────────────────── IPC ─────────────────────────
ipcMain.on('ready', (e, id) => {
  e.sender.send('config', config);
  if (id === 'music') e.sender.send('media', lastMedia);
  if (id === 'system' && lastStats) e.sender.send('stats', lastStats);
  if (id === 'battery' && lastBattery) e.sender.send('battery', visibleBatteries(lastBattery));
});
ipcMain.handle('config:set', (_e, patch) => { applyPatch(patch); return config; });
ipcMain.handle('skins:list', () => listNativeSkins());
ipcMain.handle('skins:import-folder', async () => {
  const result = await dialog.showOpenDialog({ title: 'Import a skin folder', properties: ['openDirectory'] });
  if (result.canceled || !result.filePaths[0]) return listNativeSkins();
  return importSkinFolder(result.filePaths[0]);
});
ipcMain.handle('skins:import-ini', async () => {
  const result = await dialog.showOpenDialog({ title: 'Import a Rainmeter-style INI skin', properties: ['openFile'], filters: [{ name: 'Skin INI', extensions: ['ini'] }] });
  if (result.canceled || !result.filePaths[0]) return listNativeSkins();
  ensureSkinsDir(); const src = result.filePaths[0];
  const folder = path.basename(src, path.extname(src)).replace(/[<>:"/\\|?*]/g, '_');
  let destDir = path.join(SKINS_DIR, folder), n = 2; while (fs.existsSync(destDir)) destDir = path.join(SKINS_DIR, `${folder} ${n++}`);
  fs.mkdirSync(destDir, { recursive: true }); fs.copyFileSync(src, path.join(destDir, path.basename(src)));
  return listNativeSkins();
});
ipcMain.handle('skins:load', (_e, id) => { openNativeSkin(id); return true; });
ipcMain.handle('skins:data', (_e, id) => skinPayload(String(id))); 
ipcMain.on('skins:close', (e) => { const win = BrowserWindow.fromWebContents(e.sender); if (win && win.skinId) win.close(); });
ipcMain.on('skins:refresh', (e) => { const win = BrowserWindow.fromWebContents(e.sender); if (win && win.skinId) { try { win.webContents.send('skin:data', skinPayload(win.skinId)); } catch (err) { console.error('Skin refresh failed:', err.message); } } });
ipcMain.on('media:cmd', (_e, cmd) => {
  if (ps && ps.stdin.writable && /^(playpause|next|prev|seek:[\d.]+)$/.test(String(cmd))) ps.stdin.write(cmd + '\n');
});
ipcMain.on('widget:resize', (_e, id, w, h) => { if (IDS.includes(id)) { sizes[id] = { w, h }; applySize(id); } });
ipcMain.on('widget:hit', (e, hit) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  setClickThrough(w, !(hit || config.general.editMode));
});
ipcMain.on('widget:menu', (e, id) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  Menu.buildFromTemplate([
    { label: 'Edit mode (drag to move)', type: 'checkbox', checked: config.general.editMode, click: m => applyPatch({ general: { editMode: m.checked } }) },
    { label: 'Settings…', click: openSettings },
    { label: 'Hide all widgets', click: () => setWidgetsHidden(true) },
    { label: `Remove this widget`, click: () => applyPatch({ [id]: { enabled: false } }) },
    { type: 'separator' },
    { label: 'Quit MONOLITH', click: () => app.quit() },
  ]).popup({ window: win });
});
ipcMain.on('app:action', (_e, name) => {
  name = String(name);
  if (name === 'quit') app.quit();
  else if (name === 'openFolder') shell.openPath(app.getPath('userData'));
  else if (name === 'skinStudio') openSkinManager();
  else if (name === 'resetPositions') resetPositions();
  else if (name === 'resetAll') replaceConfig({});
  else if (name === 'exportConfig') exportConfig();
  else if (name === 'importConfig') importConfig();
  else if (name.startsWith('preset:')) {
    const p = PRESET_PATCHES[name.slice(7)];
    if (p) applyPatch(structuredClone(p));
  }
});

// ───────────────────────── app lifecycle ─────────────────────────
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', openSettings);
  app.on('window-all-closed', () => { /* keep running in the tray */ });
  app.on('before-quit', () => { quitting = true; stopMedia(); stopStats(); stopBattery(); stopPin(); writeNow(); });
  app.on('will-quit', () => globalShortcut.unregisterAll());
  app.whenReady().then(() => {
    app.setAppUserModelId('com.monolith.desktop');
    registerHotkey();
    syncWidgets();
    if (FIRST_RUN) openSettings();
  });
}
