# Battery data for MONOLITH. Uses WMI first, then .NET's Windows power status
# because some modern laptops do not expose Win32_Battery consistently.
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$out = @()

try {
  $b = Get-CimInstance -ClassName Win32_Battery | Select-Object -First 1
  if ($b -and $null -ne $b.EstimatedChargeRemaining) {
    $status = [int]$b.BatteryStatus
    $out += [ordered]@{
      kind = 'laptop'; name = 'This laptop'; level = [int][math]::Max(0,[math]::Min(100,$b.EstimatedChargeRemaining))
      charging = ($status -in 6, 7, 8, 9)
      status = switch ($status) { 1 {'On battery'} 2 {'Plugged in'} 3 {'Fully charged'} 4 {'Low'} 5 {'Critical'} 6 {'Charging'} 7 {'Charging'} 8 {'Charging'} 9 {'Charging'} default {'Unknown'} }
    }
  }
} catch {}

# Fallback for laptops where Win32_Battery returns nothing.
if (-not ($out | Where-Object { $_.kind -eq 'laptop' })) {
  try {
    Add-Type -AssemblyName System.Windows.Forms
    $ps = [System.Windows.Forms.SystemInformation]::PowerStatus
    $fraction = [double]$ps.BatteryLifePercent
    if ($fraction -ge 0 -and $fraction -le 1) {
      $charging = $ps.PowerLineStatus -eq [System.Windows.Forms.PowerLineStatus]::Online
      $out += [ordered]@{
        kind = 'laptop'; name = 'This laptop'; level = [int][math]::Round($fraction * 100)
        charging = $charging
        status = if ($charging) { 'Plugged in' } elseif ($ps.BatteryChargeStatus -band [System.Windows.Forms.BatteryChargeStatus]::NoSystemBattery) { 'No battery' } else { 'On battery' }
      }
    }
  } catch {}
}

# Reliable fallback: call the native Windows GetSystemPowerStatus API directly.
# This works on many modern laptops where Win32_Battery and WinForms return no usable value.
if (-not ($out | Where-Object { $_.kind -eq 'laptop' })) {
  try {
    if (-not ('DeskWidgetsPowerStatus' -as [type])) {
      Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class DeskWidgetsPowerStatus {
  [StructLayout(LayoutKind.Sequential)]
  public struct SYSTEM_POWER_STATUS {
    public byte ACLineStatus;
    public byte BatteryFlag;
    public byte BatteryLifePercent;
    public byte SystemStatusFlag;
    public uint BatteryLifeTime;
    public uint BatteryFullLifeTime;
  }
  [DllImport("kernel32.dll", SetLastError=true)]
  public static extern bool GetSystemPowerStatus(out SYSTEM_POWER_STATUS status);
}
'@
    }
    $native = New-Object DeskWidgetsPowerStatus+SYSTEM_POWER_STATUS
    if ([DeskWidgetsPowerStatus]::GetSystemPowerStatus([ref]$native) -and
        $native.BatteryLifePercent -ne 255 -and $native.BatteryFlag -ne 128) {
      $charging = (($native.BatteryFlag -band 8) -ne 0) -or ($native.ACLineStatus -eq 1 -and $native.BatteryLifePercent -lt 100)
      $out += [ordered]@{
        kind = 'laptop'; name = 'This laptop'; level = [int]$native.BatteryLifePercent
        charging = [bool]$charging
        status = if ($charging) { 'Charging' } elseif ($native.ACLineStatus -eq 1) { 'Plugged in' } else { 'On battery' }
      }
    }
  } catch {}
}

# Bluetooth battery values are exposed only by devices/drivers that report them to Windows.
$key = '{104EA319-6EE2-4701-BD47-8DDBF425BBE5} 2'
$seen = @{}
try {
  Get-PnpDevice -PresentOnly | Where-Object {
    $_.InstanceId -like 'BTHENUM*' -or $_.InstanceId -like 'BTHLE*' -or $_.InstanceId -like 'BTH\*' -or $_.Class -eq 'Bluetooth'
  } | ForEach-Object {
    $p = Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName $key
    if ($p -and $null -ne $p.Data -and $p.Type -ne 'Empty') {
      $lvl = [int]$p.Data; $name = [string]$_.FriendlyName
      if ($lvl -ge 0 -and $lvl -le 100 -and $name -and -not $seen.ContainsKey($name)) {
        $seen[$name] = $true
        $out += [ordered]@{ kind = 'bt'; name = $name; level = $lvl; charging = $false; status = 'Bluetooth device' }
      }
    }
  }
} catch {}
[Console]::Out.WriteLine((ConvertTo-Json -InputObject @($out) -Compress))
