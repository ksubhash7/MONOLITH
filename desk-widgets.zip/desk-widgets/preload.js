const { contextBridge, ipcRenderer } = require('electron');
const on = (channel, cb) => ipcRenderer.on(channel, (_e, ...args) => cb(...args));

contextBridge.exposeInMainWorld('api', {
  ready: id => ipcRenderer.send('ready', id),
  onConfig: cb => on('config', cb),
  onMedia: cb => on('media', cb),
  onStats: cb => on('stats', cb),
  setConfig: patch => ipcRenderer.invoke('config:set', patch),
  media: cmd => ipcRenderer.send('media:cmd', cmd),
  resize: (id, w, h) => ipcRenderer.send('widget:resize', id, w, h),
  menu: id => ipcRenderer.send('widget:menu', id),
  action: name => ipcRenderer.send('app:action', name),
});
