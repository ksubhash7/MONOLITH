param([int]$PollMs = 1000)
# Long-running helper: prints one JSON line per poll with whatever Windows says is playing,
# and reads commands (playpause / next / prev / seek:<seconds>) from stdin.
$ErrorActionPreference = 'SilentlyContinue'
$utf8 = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $utf8

Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]

$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
})[0]

function Await($op, [Type]$type) {
    $task = $asTask.MakeGenericMethod($type).Invoke($null, @($op))
    $null = $task.Wait(-1)
    $task.Result
}

$mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
$stdin = New-Object System.IO.StreamReader([Console]::OpenStandardInput(), $utf8)
$cmdTask = $stdin.ReadLineAsync()

$lastKey = ''
$needArt = $false
$tries = 0

while ($true) {
    $s = $mgr.GetCurrentSession()

    # ---- commands from the app ----
    if ($cmdTask.IsCompleted) {
        $cmd = $cmdTask.Result
        if ($null -eq $cmd) { break }          # app closed the pipe -> exit
        $cmdTask = $stdin.ReadLineAsync()
        if ($s) {
            if ($cmd -eq 'playpause') { $null = Await ($s.TryTogglePlayPauseAsync()) ([bool]) }
            elseif ($cmd -eq 'next') { $null = Await ($s.TrySkipNextAsync()) ([bool]) }
            elseif ($cmd -eq 'prev') { $null = Await ($s.TrySkipPreviousAsync()) ([bool]) }
            elseif ($cmd -like 'seek:*') {
                $sec = [double]($cmd.Substring(5))
                $null = Await ($s.TryChangePlaybackPositionAsync([long]($sec * 10000000))) ([bool])
            }
        }
    }

    # ---- current state ----
    if ($null -eq $s) {
        $lastKey = ''
        $o = @{ active = $false }
    } else {
        $props = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
        $pb = $s.GetPlaybackInfo()
        $tl = $s.GetTimelineProperties()
        $key = "$($props.Title)|$($props.Artist)|$($props.AlbumTitle)"
        if ($key -ne $lastKey) { $lastKey = $key; $needArt = $true; $tries = 0 }

        $o = [ordered]@{
            active   = $true
            key      = $key
            title    = [string]$props.Title
            artist   = [string]$props.Artist
            album    = [string]$props.AlbumTitle
            app      = [string]$s.SourceAppUserModelId
            playing  = ([int]$pb.PlaybackStatus -eq 4)
            position = [math]::Round($tl.Position.TotalSeconds, 1)
            duration = [math]::Round(($tl.EndTime - $tl.StartTime).TotalSeconds, 1)
            canNext  = [bool]$pb.Controls.IsNextEnabled
            canPrev  = [bool]$pb.Controls.IsPreviousEnabled
        }

        # Album art is only sent when the track changes (some apps publish it a moment late, so retry a few polls)
        if ($needArt -and $tries -lt 6) {
            $tries++
            $art = ''
            try {
                if ($props.Thumbnail) {
                    $st = Await ($props.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
                    $net = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($st)
                    $ms = New-Object System.IO.MemoryStream
                    $net.CopyTo($ms)
                    $art = [Convert]::ToBase64String($ms.ToArray())
                    $net.Dispose(); $ms.Dispose()
                }
            } catch { }
            if ($art) { $o['art'] = $art; $needArt = $false }
            elseif ($tries -ge 6) { $o['art'] = ''; $needArt = $false }
        }
    }

    [Console]::Out.WriteLine(($o | ConvertTo-Json -Compress))
    [Console]::Out.Flush()
    Start-Sleep -Milliseconds $PollMs
}
