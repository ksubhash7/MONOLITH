# Keeps the widget windows sitting directly above the desktop (wallpaper + icons) and below every other window.
# Reads lines like "pin 123456,789012" (window handles) from stdin and re-applies the z-order every moment.
$ErrorActionPreference = 'SilentlyContinue'

Add-Type @"
using System;
using System.Runtime.InteropServices;
public class DeskPin {
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern IntPtr FindWindow(string c, string t);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern IntPtr FindWindowEx(IntPtr p, IntPtr a, string c, string t);
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);

  // The window that hosts the desktop icons (a WorkerW if one exists, otherwise Progman)
  static IntPtr Anchor() {
    IntPtr w = IntPtr.Zero;
    while ((w = FindWindowEx(IntPtr.Zero, w, "WorkerW", null)) != IntPtr.Zero) {
      if (FindWindowEx(w, IntPtr.Zero, "SHELLDLL_DefView", null) != IntPtr.Zero) return w;
    }
    return FindWindow("Progman", null);
  }
  public static void PinAll(long[] handles) {
    IntPtr a = Anchor();
    if (a == IntPtr.Zero) return;
    foreach (long h in handles) SetWindowPos(new IntPtr(h), a, 0, 0, 0, 0, 0x0013); // NOMOVE | NOSIZE | NOACTIVATE
  }
}
"@

$utf8 = New-Object System.Text.UTF8Encoding($false)
$stdin = New-Object System.IO.StreamReader([Console]::OpenStandardInput(), $utf8)
$task = $stdin.ReadLineAsync()
$handles = @()

while ($true) {
    if ($task.IsCompleted) {
        $line = $task.Result
        if ($null -eq $line) { break }          # app closed -> exit
        $task = $stdin.ReadLineAsync()
        if ($line -like 'pin *') {
            $handles = @($line.Substring(4).Split(',') | Where-Object { $_ } | ForEach-Object { [long]$_ })
        }
    }
    if ($handles.Count -gt 0) { [DeskPin]::PinAll([long[]]$handles) }
    Start-Sleep -Milliseconds 700
}
