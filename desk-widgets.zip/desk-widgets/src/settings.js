(() => {
  const FONTS = ['Segoe UI Variable', 'Segoe UI', 'Bahnschrift', 'Arial Rounded MT Bold', 'Trebuchet MS', 'Verdana', 'Candara', 'Calibri', 'Georgia', 'Consolas', 'Comic Sans MS'];
  const PRESETS = ['#8b7cff', '#ff7a9c', '#4ecdc4', '#ffb84d', '#0a84ff', '#30d158', '#ff375f', '#ff9f0a', '#bf5af2'];
  const THEMES = [['clay', 'Clay (soft & puffy)'], ['material', 'Material (tonal & flat)'], ['apple', 'Apple (iOS glass)']];
  const INTERVALS = [[500, '0.5 s'], [1000, '1 s'], [2000, '2 s'], [5000, '5 s']];

  // t = control type, p = path in config.json, l = label
  const SCHEMA = [
    { title: 'General (both widgets)', items: [
      { p: 'general.editMode', t: 'toggle', l: 'Edit mode: drag widgets to reposition them' },
      { p: 'general.layer', t: 'select', l: 'Window layer', o: [['desktop', 'Desktop only (behind apps)'], ['top', 'Always on top of apps'], ['normal', 'Normal window']] },
      { p: 'general.mode', t: 'select', l: 'Colour mode', o: [['auto', 'Follow Windows'], ['dark', 'Dark'], ['light', 'Light']] },
      { p: 'general.font', t: 'select', l: 'Font', o: FONTS },
      { p: 'general.startWithWindows', t: 'toggle', l: 'Start with Windows' },
      { p: 'general.acrylic', t: 'toggle', l: 'Acrylic blur behind widgets (experimental, Windows 11, square corners)' },
    ] },
    { title: 'Music widget', items: [
      { p: 'music.enabled', t: 'toggle', l: 'Show music widget' },
      { p: 'music.demo', t: 'toggle', l: 'Demo track (preview the look without playing music)' },
      { p: 'music.theme', t: 'select', l: 'Theme', o: THEMES },
      { p: 'music.layout', t: 'select', l: 'Layout', o: [['horizontal', 'Wide (art on the left)'], ['vertical', 'Tall (art on top)']] },
      { p: 'music.scale', t: 'range', l: 'Size', min: 0.6, max: 2, step: 0.05, fmt: v => Math.round(v * 100) + '%' },
      { p: 'music.opacity', t: 'range', l: 'Translucency (lower = more see-through)', min: 0.15, max: 1, step: 0.01, fmt: v => Math.round(v * 100) + '%' },
      { p: 'music.radius', t: 'range', l: 'Corner roundness', min: 0, max: 56, step: 1, fmt: v => v + 'px' },
      { p: 'music.accent', t: 'color', l: 'Accent colour' },
      { p: 'music.accentFromArt', t: 'toggle', l: 'Take the accent from the album art' },
      { p: 'music.artShape', t: 'select', l: 'Album art shape', o: [['rounded', 'Rounded'], ['circle', 'Circle'], ['square', 'Square']] },
      { p: 'music.spinArt', t: 'toggle', l: 'Spin circular art while playing' },
      { p: 'music.showArt', t: 'toggle', l: 'Show album art' },
      { p: 'music.showVisualizer', t: 'toggle', l: 'Show bouncing bars (animation only)' },
      { p: 'music.showProgress', t: 'toggle', l: 'Show progress bar' },
      { p: 'music.showControls', t: 'toggle', l: 'Show play / skip buttons' },
      { p: 'music.showSource', t: 'toggle', l: 'Show which app is playing' },
      { p: 'music.pollMs', t: 'select', num: true, l: 'Check for track changes every', o: INTERVALS },
    ] },
    { title: 'CPU & RAM widget', items: [
      { p: 'system.enabled', t: 'toggle', l: 'Show system widget' },
      { p: 'system.theme', t: 'select', l: 'Theme', o: THEMES },
      { p: 'system.style', t: 'select', l: 'Metric style', o: [['rings', 'Rings'], ['bars', 'Bars'], ['numbers', 'Big numbers']] },
      { p: 'system.scale', t: 'range', l: 'Size', min: 0.6, max: 2, step: 0.05, fmt: v => Math.round(v * 100) + '%' },
      { p: 'system.opacity', t: 'range', l: 'Translucency (lower = more see-through)', min: 0.15, max: 1, step: 0.01, fmt: v => Math.round(v * 100) + '%' },
      { p: 'system.radius', t: 'range', l: 'Corner roundness', min: 0, max: 56, step: 1, fmt: v => v + 'px' },
      { p: 'system.accent', t: 'color', l: 'CPU colour' },
      { p: 'system.accent2', t: 'color', l: 'RAM colour' },
      { p: 'system.accent3', t: 'color', l: 'Disk colour' },
      { p: 'system.showCpu', t: 'toggle', l: 'Show CPU' },
      { p: 'system.showRam', t: 'toggle', l: 'Show RAM' },
      { p: 'system.showDisk', t: 'toggle', l: 'Show disk usage' },
      { p: 'system.diskDrive', t: 'text', l: 'Drive to monitor (e.g. C: or D:)' },
      { p: 'system.showGraph', t: 'toggle', l: 'Show history graph' },
      { p: 'system.showCores', t: 'toggle', l: 'Show per-core bars' },
      { p: 'system.showCpuName', t: 'toggle', l: 'Show processor name' },
      { p: 'system.showUptime', t: 'toggle', l: 'Show uptime' },
      { p: 'system.intervalMs', t: 'select', num: true, l: 'Refresh every', o: INTERVALS },
    ] },
    { title: 'Advanced', hint: 'Custom CSS is injected into both widgets. Try: .card { border: 2px solid hotpink; }', items: [
      { p: 'general.customCss', t: 'textarea', l: 'Custom CSS' },
    ], actions: true },
  ];

  const root = document.getElementById('root');
  const controls = {};            // path -> { it, input, out }
  let cfg = null;

  const get = (o, p) => p.split('.').reduce((a, k) => (a == null ? a : a[k]), o);
  const send = (p, v) => {
    const keys = p.split('.'), patch = {};
    let cur = patch;
    keys.forEach((k, i) => { cur[k] = i === keys.length - 1 ? v : {}; cur = cur[k]; });
    window.api.setConfig(patch);
  };
  const el = (tag, props = {}, kids = []) => {
    const e = Object.assign(document.createElement(tag), props);
    kids.forEach(k => e.append(k));
    return e;
  };

  function makeControl(it) {
    const row = el('label', { className: 'row' + (it.t === 'textarea' ? ' col' : '') });
    row.append(el('span', { className: 'lbl', textContent: it.l }));
    const box = el('span', { className: 'ctl' });
    let input, out = null;

    if (it.t === 'toggle') {
      input = el('input', { type: 'checkbox', className: 'switch' });
      input.onchange = () => send(it.p, input.checked);
    } else if (it.t === 'select') {
      input = el('select');
      it.o.forEach(o => { const [v, t] = Array.isArray(o) ? o : [o, o]; input.append(el('option', { value: v, textContent: t })); });
      input.onchange = () => send(it.p, it.num ? Number(input.value) : input.value);
    } else if (it.t === 'range') {
      input = el('input', { type: 'range', min: it.min, max: it.max, step: it.step });
      out = el('span', { className: 'val' });
      input.oninput = () => { const v = Number(input.value); out.textContent = it.fmt(v); send(it.p, v); };
    } else if (it.t === 'color') {
      input = el('input', { type: 'color' });
      input.oninput = () => send(it.p, input.value);
      const sw = el('span', { className: 'sw' });
      PRESETS.forEach(c => {
        const b = el('button', { type: 'button', title: c });
        b.style.background = c;
        b.onclick = e => { e.preventDefault(); input.value = c; send(it.p, c); };
        sw.append(b);
      });
      box.append(sw);
    } else if (it.t === 'text') {
      input = el('input', { type: 'text' });
      input.onchange = () => send(it.p, input.value.trim());
    } else if (it.t === 'textarea') {
      input = el('textarea', { spellcheck: false });
      input.oninput = () => send(it.p, input.value);
    }
    box.append(input);
    if (out) box.append(out);
    row.append(box);
    controls[it.p] = { it, input, out };
    return row;
  }

  function build() {
    SCHEMA.forEach(sec => {
      const s = el('section');
      s.append(el('h2', { textContent: sec.title }));
      if (sec.hint) s.append(el('p', { className: 'hint', textContent: sec.hint }));
      sec.items.forEach(it => s.append(makeControl(it)));
      if (sec.actions) {
        const a = el('div', { className: 'actions' });
        [['Reset widget positions', 'resetPositions', ''], ['Open config folder', 'openFolder', ''], ['Reset everything', 'resetAll', 'danger'], ['Quit Desk Widgets', 'quit', 'danger']]
          .forEach(([t, name, cls]) => a.append(el('button', { className: 'btn ' + cls, textContent: t, type: 'button', onclick: () => window.api.action(name) })));
        s.append(a);
      }
      root.append(s);
    });
  }

  function sync() {
    for (const [p, c] of Object.entries(controls)) {
      const v = get(cfg, p);
      if (document.activeElement === c.input || v === undefined) continue;
      if (c.it.t === 'toggle') c.input.checked = !!v;
      else if (c.it.t === 'range') { c.input.value = v; c.out.textContent = c.it.fmt(Number(v)); }
      else c.input.value = v;
    }
  }

  build();
  window.api.onConfig(c => { cfg = c; sync(); });
  window.api.ready('settings');
})();
