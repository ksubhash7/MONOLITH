(() => {
  const $ = id => document.getElementById(id);
  const card = $('card'), artWrap = $('artwrap'), artImg = $('art'), fb = $('fb');
  const title = $('title'), artist = $('artist'), src = $('src'), viz = $('viz');
  const prog = $('prog'), bar = $('bar'), fill = $('fill'), thumb = $('thumb'), tc = $('tc'), td = $('td');
  const controls = $('controls'), bPrev = $('prev'), bPlay = $('play'), bNext = $('next'), playPath = $('playpath');
  const ICON = { play: 'M8 5v14l11-7z', pause: 'M6 19h4V5H6v14zm8-14v14h4V5h-4z' };
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  let S = { active: false, title: '', artist: '', app: '', playing: false, position: 0, duration: 0, key: '', art: null, at: performance.now(), unsupported: false };
  let artAccent = null;
  let wasDemo = false;
  let titleKey = '';

  const demo = () => !!(W.cfg && W.cfg.music.demo);
  const fmt = s => { s = Math.max(0, Math.floor(s || 0)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
  const pos = () => S.playing ? Math.min(S.duration || Infinity, S.position + (performance.now() - S.at) / 1000) : S.position;

  function prettyApp(a) {
    if (!a) return '';
    const n = a.split('!')[0].replace(/\.exe$/i, '').split(/[\\/]/).pop();
    const map = { chrome: 'Chrome', msedge: 'Edge', spotify: 'Spotify', firefox: 'Firefox', brave: 'Brave', vlc: 'VLC', demo: 'Demo' };
    const k = n.toLowerCase();
    return map[k] || (n.charAt(0).toUpperCase() + n.slice(1));
  }

  // ---- album colour ----
  function rgb2hsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b); let h = 0, s = 0; const l = (mx + mn) / 2;
    if (mx !== mn) {
      const d = mx - mn; s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn);
      h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6;
    }
    return [h, s, l];
  }
  function hsl2rgb(h, s, l) {
    const f = (p, q, t) => { if (t < 0) t += 1; if (t > 1) t -= 1; if (t < 1 / 6) return p + (q - p) * 6 * t; if (t < .5) return q; if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6; return p; };
    if (s === 0) { const v = l * 255; return [v, v, v]; }
    const q = l < .5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    return [f(p, q, h + 1 / 3) * 255, f(p, q, h) * 255, f(p, q, h - 1 / 3) * 255];
  }
  function dominant(img) {
    const cv = document.createElement('canvas'); cv.width = cv.height = 24;
    const g = cv.getContext('2d'); g.drawImage(img, 0, 0, 24, 24);
    const d = g.getImageData(0, 0, 24, 24).data; let r = 0, gg = 0, b = 0, wsum = 0;
    for (let i = 0; i < d.length; i += 4) {
      const sat = Math.max(d[i], d[i + 1], d[i + 2]) - Math.min(d[i], d[i + 1], d[i + 2]);
      const w = sat * sat + 1; r += d[i] * w; gg += d[i + 1] * w; b += d[i + 2] * w; wsum += w;
    }
    let [h, s, l] = rgb2hsl(r / wsum, gg / wsum, b / wsum);
    s = clamp(s, .45, .9); l = clamp(l, .5, .62);
    return W.rgb2hex(hsl2rgb(h, s, l));
  }
  function setArt(b64) {
    S.art = b64 || null;
    if (!b64) { artImg.removeAttribute('src'); artAccent = null; paintArt(); applyTheme(); return; }
    const mime = b64.startsWith('/9j/') ? 'image/jpeg' : b64.startsWith('iVBOR') ? 'image/png' : b64.startsWith('UklG') ? 'image/webp' : b64.startsWith('R0lG') ? 'image/gif' : 'image/jpeg';
    const url = `data:${mime};base64,${b64}`;
    artImg.src = url;
    paintArt();
    const im = new Image();
    im.onload = () => { try { artAccent = dominant(im); applyTheme(); } catch { /* keep manual accent */ } };
    im.src = url;
  }
  function paintArt() { artImg.hidden = !S.art; fb.hidden = !!S.art; }
  function applyTheme() {
    if (!W.cfg) return;
    const c = W.cfg.music;
    W.apply(c.accentFromArt && artAccent ? artAccent : c.accent);
  }

  // ---- render ----
  function render() {
    if (!W.cfg) return;
    const c = W.cfg.music;
    card.classList.toggle('horizontal', c.layout === 'horizontal');
    card.classList.toggle('vertical', c.layout === 'vertical');
    artWrap.dataset.shape = c.artShape;
    artWrap.classList.toggle('spin', c.spinArt && c.artShape === 'circle');
    artWrap.classList.toggle('playing', S.playing);
    artWrap.hidden = !c.showArt;
    viz.hidden = !c.showVisualizer;
    viz.classList.toggle('on', S.playing);
    controls.hidden = !c.showControls;
    prog.hidden = !c.showProgress || !(S.duration > 0);
    src.hidden = !c.showSource || !S.active;
    src.textContent = prettyApp(S.app);

    const t = S.active ? (S.title || 'Unknown title') : (S.unsupported ? 'Windows only' : 'Nothing playing');
    const k = t + '|' + c.layout + '|' + c.showArt + '|' + c.showVisualizer;
    if (k !== titleKey) {
      titleKey = k;
      const span = title.firstElementChild;
      span.textContent = t;
      title.classList.remove('marquee');
      requestAnimationFrame(() => {
        const over = span.offsetWidth - title.clientWidth;
        if (over > 2) { title.style.setProperty('--d', -(over + 10) + 'px'); title.classList.add('marquee'); }
      });
    }
    artist.textContent = S.active ? S.artist : (S.unsupported ? 'Media info needs Windows' : 'Play something in Spotify, YouTube…');
    playPath.setAttribute('d', S.playing ? ICON.pause : ICON.play);
    bPlay.classList.toggle('playing', S.playing);
    bPrev.disabled = !S.active; bNext.disabled = !S.active; bPlay.disabled = !S.active;
    tick();
  }
  function tick() {
    const p = pos(), f = S.duration > 0 ? clamp(p / S.duration, 0, 1) : 0;
    fill.style.width = (f * 100) + '%';
    thumb.style.left = (f * 100) + '%';
    tc.textContent = fmt(p); td.textContent = fmt(S.duration);
  }
  setInterval(() => { if (W.cfg && S.playing) tick(); }, 250);

  // ---- demo track (so you can preview themes without playing anything) ----
  function startDemo() {
    const cv = document.createElement('canvas'); cv.width = cv.height = 200;
    const g = cv.getContext('2d'), gr = g.createLinearGradient(0, 0, 200, 200);
    gr.addColorStop(0, '#ff7ab8'); gr.addColorStop(.55, '#8b7cff'); gr.addColorStop(1, '#35d6c4');
    g.fillStyle = gr; g.fillRect(0, 0, 200, 200);
    g.fillStyle = 'rgba(255,255,255,.22)';
    g.beginPath(); g.arc(70, 70, 46, 0, 7); g.fill();
    g.beginPath(); g.arc(140, 140, 62, 0, 7); g.fill();
    S = { active: true, title: 'Midnight Drive (demo track with a very long title)', artist: 'Desk Widgets', app: 'Demo.exe', playing: true, position: 42, duration: 243, key: 'demo', art: null, at: performance.now(), unsupported: false };
    setArt(cv.toDataURL('image/png').split(',')[1]);
  }

  // ---- messages from main ----
  window.api.onMedia(m => {
    if (demo()) return;
    if (m.active === false) {
      S = { ...S, active: false, playing: false, title: '', artist: '', app: '', key: '', duration: 0, position: 0, unsupported: !!m.unsupported, at: performance.now() };
      setArt(null);
    } else {
      const hasArt = 'art' in m;
      if (m.key !== S.key && !hasArt) setArt(null);
      S = { ...S, ...m, active: true, unsupported: false, at: performance.now() };
      if (hasArt) setArt(m.art);
    }
    render();
  });

  // ---- controls ----
  bPlay.onclick = () => {
    S.position = pos(); S.at = performance.now(); S.playing = !S.playing;
    if (!demo()) window.api.media('playpause');
    render();
  };
  const restartDemo = () => { S.position = 0; S.at = performance.now(); render(); };
  bNext.onclick = () => demo() ? restartDemo() : window.api.media('next');
  bPrev.onclick = () => demo() ? restartDemo() : window.api.media('prev');
  bar.onclick = e => {
    if (!(S.duration > 0)) return;
    const r = bar.getBoundingClientRect();
    const sec = clamp((e.clientX - r.left) / r.width, 0, 1) * S.duration;
    S.position = sec; S.at = performance.now();
    if (!demo()) window.api.media('seek:' + sec.toFixed(1));
    tick();
  };

  W.refresh = applyTheme;
  W.init('music', cfg => {
    if (cfg.music.demo && !wasDemo) startDemo();
    if (!cfg.music.demo && wasDemo) { wasDemo = false; S = { ...S, active: false, playing: false, key: '' }; setArt(null); window.api.ready('music'); }
    wasDemo = cfg.music.demo;
    applyTheme();
    render();
  });
})();
