'use strict';
const { app, BrowserWindow, Tray, Menu, ipcMain, nativeImage, screen, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');

// ───────────────────────── defaults (every key here is editable in Settings) ─────────────────────────
const DEFAULTS = {
  general: {
    layer: 'desktop',        // 'desktop' = only on the desktop (behind apps), 'top' = above everything, 'normal' = regular window
    startWithWindows: false,
    editMode: false,         // true = drag widgets around
    mode: 'auto',            // 'auto' | 'dark' | 'light'
    font: 'Segoe UI Variable',
    acrylic: false,          // experimental real blur on Windows 11 (square corners)
    customCss: '',
  },
  music: {
    enabled: true, demo: false,
    theme: 'clay',           // 'clay' | 'material'
    layout: 'horizontal',    // 'horizontal' | 'vertical'
    scale: 1, opacity: 0.82, radius: 32,
    accent: '#8b7cff', accentFromArt: true,
    artShape: 'rounded',     // 'rounded' | 'circle' | 'square'
    spinArt: false,
    showArt: true, showVisualizer: true, showProgress: true, showControls: true, showSource: true,
    pollMs: 1000,
    x: null, y: null,
  },
  system: {
    enabled: true,
    theme: 'material',
    scale: 1, opacity: 0.82, radius: 28,
    accent: '#ff7a9c', accent2: '#4ecdc4', accent3: '#ffb84d',   // CPU, RAM, Disk colours
    style: 'rings',          // 'rings' | 'bars' | 'numbers'
    showCpu: true, showRam: true, showDisk: false,
    showGraph: true, showCores: false, showUptime: true, showCpuName: true,
    intervalMs: 1000,
    diskDrive: 'C:',
    x: null, y: null,
  },
};

// ───────────────────────── config storage ─────────────────────────
const CONFIG_PATH = path.join(app.getPath('userData'), 'config.json');
const FIRST_RUN = !fs.existsSync(CONFIG_PATH);

function readJson(p) { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; } }
function deepMerge(t, s) {
  for (const k of Object.keys(s || {})) {
    if (s[k] && typeof s[k] === 'object' && !Array.isArray(s[k])) {
      t[k] = deepMerge(t[k] && typeof t[k] === 'object' ? t[k] : {}, s[k]);
    } else t[k] = s[k];
  }
  return t;
}
let config = deepMerge(structuredClone(DEFAULTS), readJson(CONFIG_PATH) || {});

let persistTimer = null;
function writeNow() {
  try {
    fs.mkdirSync(path.dirname(CONFIG_PATH), { recursive: true });
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
  } catch (e) { console.error('config save failed', e); }
}
function schedulePersist() { clearTimeout(persistTimer); persistTimer = setTimeout(writeNow, 300); }

// ───────────────────────── state ─────────────────────────
const IDS = ['music', 'system'];
const wins = {};            // widget windows
const sizes = {};           // last CSS size reported by each widget
let settingsWin = null;
let tray = null;
let quitting = false;   // only true when the user really quits (tray > Quit)
let hinted = false;

const webPreferences = {
  preload: path.join(__dirname, 'preload.js'),
  contextIsolation: true,
  nodeIntegration: false,
  backgroundThrottling: false,
};

// ───────────────────────── layer: desktop / top / normal ─────────────────────────
function scriptPath(name) {
  return path.join(__dirname, 'scripts', name).replace(`app.asar${path.sep}`, `app.asar.unpacked${path.sep}`);
}
// 'desktop' = pinned just above the wallpaper/icons. While editing, widgets jump on top so you can find and drag them.
function applyLayer(w) {
  if (!w || w.isDestroyed()) return;
  const l = config.general.layer, editing = !!config.general.editMode;
  w.setFocusable(l !== 'desktop' || editing);
  if (l === 'top' || (l === 'desktop' && editing)) w.setAlwaysOnTop(true, 'floating');
  else w.setAlwaysOnTop(false);
}
let pin = null;
function hwndOf(win) {
  const b = win.getNativeWindowHandle();
  return b.length >= 8 ? Number(b.readBigUInt64LE(0)) : b.readUInt32LE(0);
}
function stopPin() { if (pin) { try { pin.kill(); } catch { /* ignore */ } pin = null; } }
function syncPin() {
  if (process.platform !== 'win32') return;
  const live = Object.values(wins).filter(w => w && !w.isDestroyed());
  if (config.general.layer !== 'desktop' || !live.length) { stopPin(); return; }
  if (!pin) {
    pin = spawn('powershell.exe',
      ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', scriptPath('pin.ps1')],
      { windowsHide: true });
    pin.stderr.on('data', d => console.error('[pin.ps1]', String(d)));
    pin.on('exit', () => { pin = null; });
  }
  const handles = config.general.editMode ? [] : live.map(hwndOf);   // don't fight the user while dragging
  if (pin && pin.stdin.writable) pin.stdin.write('pin ' + handles.join(',') + '\n');
}

// ───────────────────────── widget windows ─────────────────────────
function defaultPos(id) {
  const wa = screen.getPrimaryDisplay().workArea;
  const sz = sizes[id] || { w: 420, h: 220 };
  const s = (config[id] && config[id].scale) || 1;
  return id === 'music'
    ? { x: Math.round(wa.x + wa.width - sz.w * s - 16), y: wa.y + 16 }
    : { x: wa.x + 16, y: wa.y + 16 };
}
function onSomeDisplay(x, y) {
  return screen.getAllDisplays().some(d => {
    const b = d.bounds;
    return x >= b.x - 40 && x < b.x + b.width - 60 && y >= b.y - 10 && y < b.y + b.height - 60;
  });
}

function createWidget(id) {
  if (wins[id] && !wins[id].isDestroyed()) return;
  const c = config[id];
  const acrylic = !!config.general.acrylic;
  const pos = (c.x != null && c.y != null && onSomeDisplay(c.x, c.y)) ? { x: c.x, y: c.y } : defaultPos(id);

  const win = new BrowserWindow({
    ...pos, width: 420, height: 220, minWidth: 50, minHeight: 50, useContentSize: true,
    frame: false, transparent: !acrylic, backgroundColor: '#00000000',
    ...(acrylic ? { backgroundMaterial: 'acrylic' } : {}),
    resizable: false, maximizable: false, minimizable: false, fullscreenable: false,
    skipTaskbar: true, hasShadow: false, show: false,
    focusable: config.general.layer !== 'desktop' || config.general.editMode,
    webPreferences,
  });
  applyLayer(win);
  win.setMenuBarVisibility(false);
  win.on('show', syncPin);
  win.loadFile(path.join(__dirname, 'src', id + '.html'));
  win.webContents.on('dom-ready', () => win.webContents.setZoomFactor(config[id].scale || 1));

  let t;
  win.on('move', () => {
    clearTimeout(t);
    t = setTimeout(() => {
      if (win.isDestroyed()) return;
      const [x, y] = win.getPosition();
      config[id].x = x; config[id].y = y;
      schedulePersist();
    }, 300);
  });
  win.on('close', e => { if (!quitting) e.preventDefault(); });   // widgets only go away via Settings / tray
  win.on('closed', () => { delete wins[id]; delete sizes[id]; });
  wins[id] = win;
}
function destroyWidget(id) {
  const w = wins[id];
  if (w && !w.isDestroyed()) w.destroy();
  delete wins[id];
}
function applySize(id) {
  const win = wins[id], sz = sizes[id];
  if (!win || win.isDestroyed() || !sz) return;
  const s = config[id].scale || 1;
  win.setContentSize(Math.ceil(sz.w * s), Math.ceil(sz.h * s));
  if (!win.isVisible()) win.showInactive();
}
function syncWidgets() {
  for (const id of IDS) config[id].enabled ? createWidget(id) : destroyWidget(id);
  syncMedia();
  syncStats();
  syncPin();
  buildTray();
}

// ───────────────────────── settings window ─────────────────────────
function openSettings() {
  if (settingsWin && !settingsWin.isDestroyed()) { settingsWin.show(); settingsWin.focus(); return; }
  settingsWin = new BrowserWindow({
    width: 860, height: 740, minWidth: 660, minHeight: 480,
    title: 'Desk Widgets — Settings', backgroundColor: '#14121c', autoHideMenuBar: true,
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences,
  });
  settingsWin.removeMenu();
  settingsWin.loadFile(path.join(__dirname, 'src', 'settings.html'));
  settingsWin.on('close', e => {
    if (quitting) return;
    e.preventDefault();
    settingsWin.hide();          // keep running in the system tray
    hintTray();
  });
  settingsWin.on('closed', () => { settingsWin = null; });
}

// ───────────────────────── tray ─────────────────────────
function hintTray() {
  if (hinted || !tray || process.platform !== 'win32') return;
  hinted = true;
  try {
    tray.displayBalloon({
      iconType: 'info',
      title: 'Desk Widgets is still running',
      content: 'It lives in the system tray (the ^ arrow near the clock). Right-click the icon for options or to quit.',
    });
  } catch { /* ignore */ }
}
function buildTray() {
  if (!tray) {
    const img = nativeImage.createFromPath(path.join(__dirname, 'assets', 'icon.png')).resize({ width: 16, height: 16 });
    tray = new Tray(img);
    tray.setToolTip('Desk Widgets');
    tray.on('click', openSettings);
    tray.on('double-click', openSettings);
  }
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Music widget', type: 'checkbox', checked: config.music.enabled, click: m => applyPatch({ music: { enabled: m.checked } }) },
    { label: 'System widget', type: 'checkbox', checked: config.system.enabled, click: m => applyPatch({ system: { enabled: m.checked } }) },
    { type: 'separator' },
    { label: 'Edit mode (drag widgets)', type: 'checkbox', checked: config.general.editMode, click: m => applyPatch({ general: { editMode: m.checked } }) },
    { label: 'Settings…', click: openSettings },
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() },
  ]));
}

// ───────────────────────── config updates ─────────────────────────
function setAutoStart(on) {
  try {
    app.setLoginItemSettings(app.isPackaged
      ? { openAtLogin: on }
      : { openAtLogin: on, path: process.execPath, args: [app.getAppPath()] });
  } catch (e) { console.error(e); }
}
function allWindows() { return [...Object.values(wins), settingsWin].filter(w => w && !w.isDestroyed()); }
function broadcastConfig() { for (const w of allWindows()) w.webContents.send('config', config); }

function applyPatch(patch) {
  deepMerge(config, patch);
  schedulePersist();
  const g = patch.general || {}, m = patch.music || {}, s = patch.system || {};

  if ('layer' in g || 'editMode' in g) {
    for (const w of Object.values(wins)) applyLayer(w);
    syncPin();
  }
  if ('startWithWindows' in g) setAutoStart(!!g.startWithWindows);
  if ('acrylic' in g) for (const id of IDS) destroyWidget(id);   // window must be recreated

  for (const id of IDS) {
    if (patch[id] && 'scale' in patch[id] && wins[id]) {
      wins[id].webContents.setZoomFactor(config[id].scale);
      applySize(id);
    }
  }

  if ('acrylic' in g || 'enabled' in m || 'enabled' in s) syncWidgets();
  else {
    if ('demo' in m || 'pollMs' in m) syncMedia();
    if ('intervalMs' in s) syncStats();
  }
  if ('editMode' in g) buildTray();
  broadcastConfig();
}

// ───────────────────────── system stats ─────────────────────────
let prevCpu = os.cpus();
let statsTimer = null;
let lastStats = null;

function sampleStats() {
  const cur = os.cpus();
  let idleAll = 0, totalAll = 0;
  const cores = [];
  cur.forEach((c, i) => {
    const p = prevCpu[i] || c;
    let total = 0;
    for (const k in c.times) total += c.times[k] - p.times[k];
    const idle = c.times.idle - p.times.idle;
    idleAll += idle; totalAll += total;
    cores.push(total > 0 ? Math.round((1 - idle / total) * 100) : 0);
  });
  prevCpu = cur;

  const totalMem = os.totalmem(), freeMem = os.freemem();
  let disk = null;
  try {
    const drive = (config.system.diskDrive || 'C:').replace(/[\\/]+$/, '') + '\\';
    const st = fs.statfsSync(drive);
    const total = st.blocks * st.bsize, free = st.bavail * st.bsize;
    disk = { total, used: total - free, pct: ((total - free) / total) * 100, drive: drive.slice(0, 2) };
  } catch { /* drive missing */ }

  return {
    cpu: totalAll > 0 ? (1 - idleAll / totalAll) * 100 : 0,
    cores,
    cpuName: (cur[0] && cur[0].model ? cur[0].model : 'CPU').replace(/\s+/g, ' ').trim(),
    ram: { total: totalMem, used: totalMem - freeMem, pct: ((totalMem - freeMem) / totalMem) * 100 },
    disk,
    uptime: os.uptime(),
  };
}
function stopStats() { clearInterval(statsTimer); statsTimer = null; }
function syncStats() {
  stopStats();
  if (!wins.system) return;
  const tick = () => {
    lastStats = sampleStats();
    if (wins.system && !wins.system.isDestroyed()) wins.system.webContents.send('stats', lastStats);
  };
  tick();
  statsTimer = setInterval(tick, Math.max(250, config.system.intervalMs || 1000));
}

// ───────────────────────── media (Windows "now playing") ─────────────────────────
let ps = null;
let wantMedia = false;
let lastMedia = { active: false };
let lastKey = '';

function emitMedia(m) {
  if (m.active) {
    const same = m.key === lastKey;
    lastKey = m.key;
    lastMedia = { ...m, art: ('art' in m) ? m.art : (same ? lastMedia.art : null) };
  } else { lastKey = ''; lastMedia = m; }
  if (wins.music && !wins.music.isDestroyed()) wins.music.webContents.send('media', m);
}
function startMedia() {
  const script = scriptPath('media.ps1');
  ps = spawn('powershell.exe',
    ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script, String(config.music.pollMs || 1000)],
    { windowsHide: true });
  let buf = '';
  ps.stdout.setEncoding('utf8');
  ps.stdout.on('data', d => {
    buf += d;
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (line) { try { emitMedia(JSON.parse(line)); } catch { /* partial line */ } }
    }
  });
  ps.stderr.on('data', d => console.error('[media.ps1]', String(d)));
  ps.on('exit', () => { ps = null; if (wantMedia) setTimeout(() => { if (wantMedia && !ps) startMedia(); }, 2000); });
}
function stopMedia() {
  wantMedia = false;
  if (ps) { try { ps.kill(); } catch { /* ignore */ } ps = null; }
}
function syncMedia() {
  stopMedia();
  if (!wins.music || config.music.demo) return;
  if (process.platform !== 'win32') { emitMedia({ active: false, unsupported: true }); return; }
  wantMedia = true;
  startMedia();
}

// ───────────────────────── IPC ─────────────────────────
ipcMain.on('ready', (e, id) => {
  e.sender.send('config', config);
  if (id === 'music') e.sender.send('media', lastMedia);
  if (id === 'system' && lastStats) e.sender.send('stats', lastStats);
});
ipcMain.handle('config:set', (_e, patch) => { applyPatch(patch); return config; });
ipcMain.on('media:cmd', (_e, cmd) => {
  if (ps && ps.stdin.writable && /^(playpause|next|prev|seek:[\d.]+)$/.test(String(cmd))) ps.stdin.write(cmd + '\n');
});
ipcMain.on('widget:resize', (_e, id, w, h) => { if (IDS.includes(id)) { sizes[id] = { w, h }; applySize(id); } });
ipcMain.on('widget:menu', (e, id) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  Menu.buildFromTemplate([
    { label: 'Edit mode (drag to move)', type: 'checkbox', checked: config.general.editMode, click: m => applyPatch({ general: { editMode: m.checked } }) },
    { label: 'Settings…', click: openSettings },
    { label: `Hide ${id} widget`, click: () => applyPatch({ [id]: { enabled: false } }) },
    { type: 'separator' },
    { label: 'Quit Desk Widgets', click: () => app.quit() },
  ]).popup({ window: win });
});
ipcMain.on('app:action', (_e, name) => {
  if (name === 'quit') app.quit();
  else if (name === 'openFolder') shell.openPath(app.getPath('userData'));
  else if (name === 'resetPositions') {
    for (const id of IDS) {
      config[id].x = null; config[id].y = null;
      if (wins[id]) { const p = defaultPos(id); wins[id].setPosition(p.x, p.y); }
    }
    schedulePersist();
  } else if (name === 'resetAll') {
    config = structuredClone(DEFAULTS);
    setAutoStart(false);
    schedulePersist();
    for (const id of IDS) destroyWidget(id);
    syncWidgets();
    broadcastConfig();
  }
});

// ───────────────────────── app lifecycle ─────────────────────────
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', openSettings);
  app.on('window-all-closed', () => { /* keep running in the tray */ });
  app.on('before-quit', () => { quitting = true; stopMedia(); stopStats(); stopPin(); writeNow(); });
  app.whenReady().then(() => {
    app.setAppUserModelId('com.deskwidgets.app');
    syncWidgets();
    if (FIRST_RUN) openSettings();
  });
}
