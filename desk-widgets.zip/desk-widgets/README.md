# Desk Widgets

Two desktop widgets for Windows, built with Electron:

- Themes: **Clay**, **Material**, **Apple** (iOS-style glass, SF Pro font if installed)
- **Music widget**: shows whatever Windows says is playing (Spotify, YouTube in Chrome/Edge, etc.) with album art, progress, and play / skip / seek. Clay or Material theme.
- **CPU & RAM widget**: rings, bars or big numbers, plus a history graph, per-core bars, disk usage and uptime.

## Run

1. Install Node.js LTS from https://nodejs.org
2. Double-click `start.bat` (first run installs Electron, about 100 MB)

`start.bat` closes itself after launching, so the widgets keep running with no command window.
After the first run you can also just double-click `start-hidden.vbs`.
To stop them: tray icon > Quit.

(Developers: `npm install` then `npm start` runs it attached to the terminal.)

## Use

- Tray icon (bottom-right, near the clock): toggle widgets, edit mode, settings, quit.
- Right-click a widget: edit mode, settings, hide.
- Edit mode: drag a widget, then click **Done**. Positions are remembered.
- Settings window: every option applies live.
- Settings file: `%APPDATA%\desk-widgets\config.json` (editable by hand, restart after editing).

## Make a standalone .exe

    npm run dist

The portable exe appears in `dist/`. Run it once and turn on "Start with Windows" in Settings.

## Desktop only

Settings > Window layer > **Desktop only** keeps widgets just above the wallpaper/icons and below every app (this is the default).
Edit mode temporarily lifts them above apps so you can find and drag them; click **Done** to drop them back.

## Notes

- The "bouncing bars" on the music widget are an animation, not a real audio analyser.
- Acrylic blur is experimental: Windows draws the corners, so the clay roundness is ignored.
- Without acrylic, widgets are see-through (no blur). Lower "Translucency" to see more of the wallpaper.
